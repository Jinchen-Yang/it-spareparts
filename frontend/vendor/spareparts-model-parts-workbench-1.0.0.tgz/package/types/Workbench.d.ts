import type { ReactNode } from "react";
import type { Commit, Examples, FindCandidates } from "./operations";
import type { Catalog } from "./types.ts";
interface WorkbenchProps {
    catalog: Catalog;
    commit: Commit;
    canMaintain: boolean;
    requireMembershipVersion?: boolean;
    findCandidates?: FindCandidates;
    maintenanceUrl?: string | null;
    examples?: Examples;
    header?: ReactNode;
    noticeBar?: ReactNode;
    toolbar?: ReactNode;
}
export default function Workbench({ catalog, commit, canMaintain, requireMembershipVersion, findCandidates, maintenanceUrl, examples, header, noticeBar, toolbar }: WorkbenchProps): import("react").JSX.Element;
export {};
