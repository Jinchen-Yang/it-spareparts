import { type FindCandidates, type Receipt } from "./operations";
import type { Catalog } from "./types";
export type PoolView = {
    catalog: Catalog;
    canMaintain: boolean;
    maintenanceUrl: string | null;
    stockStatus: "live" | "unavailable";
    stockAsOf: string | null;
};
export type PoolHost = {
    read(signal: AbortSignal): Promise<PoolView>;
    candidates: FindCandidates;
    command(input: Record<string, unknown>): Promise<Receipt>;
};
export default function LivePage({ host }: {
    host: PoolHost;
}): import("react").JSX.Element;
