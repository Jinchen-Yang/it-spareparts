import type { ImportChoices, ImportRow, Part } from "./types";
export type PoolAction = {
    action: "create";
    brand: string;
    name: string;
    aliases: string[];
} | {
    action: "import";
    modelId: string;
    text: string;
    choices: ImportChoices;
    rows: ImportRow[];
} | {
    action: "resolve";
    pendingId: string;
    partId: string;
    source: string;
} | {
    action: "remove";
    modelId: string;
    partId: string;
    expectedMembershipVersion?: string;
};
export interface Receipt {
    revision: number;
    modelId?: string;
    added?: number;
    pending?: number;
    skipped?: number;
}
export type Commit = (action: PoolAction, expectedRevision: number) => Promise<Receipt>;
export type CandidateReply = {
    parts: Part[];
    matches?: Record<string, string[]>;
};
export type FindCandidates = (input: {
    q?: string;
    pns?: string[];
}, signal: AbortSignal) => Promise<CandidateReply>;
export declare function validMembershipVersion(value: string | undefined): boolean;
/** 精确批查按服务端对每个输入的档案判定预览；一项缺失时保留草稿供重试。 */
export declare function exactPartsByPn(pns: string[], reply: CandidateReply): Map<string, Part[]>;
export interface Examples {
    defaultModel: string;
    queries: {
        title: string;
        caption: string;
        q: string;
        stock: "all" | "good";
    }[];
    paste: string;
    sheet: string;
}
export declare function commandBody(action: PoolAction): Record<string, unknown>;
