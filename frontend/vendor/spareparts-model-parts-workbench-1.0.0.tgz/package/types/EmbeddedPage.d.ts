import { type PoolHost } from "./LivePage";
export type { PoolHost, PoolView } from "./LivePage";
export default function EmbeddedPage({ host }: {
    host: PoolHost;
}): import("react").JSX.Element;
