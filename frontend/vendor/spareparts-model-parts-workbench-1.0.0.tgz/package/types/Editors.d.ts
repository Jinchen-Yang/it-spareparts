import type { ReactNode } from "react";
import { type Commit, type Examples, type FindCandidates } from "./operations";
import type { Catalog, Pending } from "./types.ts";
export interface EditorProps {
    state: Catalog;
    onClose: () => void;
    commit: Commit;
    findCandidates?: FindCandidates;
    examples?: Examples;
    onSaved: (message: string, modelId?: string) => void;
}
interface DialogProps {
    title: string;
    subtitle?: string;
    wide?: boolean;
    className?: string;
    children: ReactNode;
    onClose: () => void;
}
export declare function Dialog({ title, subtitle, wide, className, children, onClose }: DialogProps): import("react").JSX.Element;
export declare function ModelEditor({ state, onClose, commit, onSaved }: EditorProps): import("react").JSX.Element;
export declare function ImportEditor({ state, modelId, onClose, commit, findCandidates, examples, onSaved }: EditorProps & {
    modelId: string;
}): import("react").JSX.Element;
export declare function PendingEditor({ state, row, onClose, commit, findCandidates, onSaved }: EditorProps & {
    row: Pending;
}): import("react").JSX.Element;
export {};
