import type { Catalog, SearchFilters, SearchResult } from "./types.ts";
/** PN 比较只统一宽窄、大小写和两端空白。型号后缀和 PN 内的分隔符有业务含义。 */
export declare function key(text: string): string;
export declare function searchCatalog(state: Catalog, filters: SearchFilters): SearchResult[];
