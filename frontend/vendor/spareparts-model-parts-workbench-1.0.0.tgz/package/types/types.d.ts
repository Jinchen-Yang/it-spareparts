export interface Machine {
    id: string;
    brand: string;
    name: string;
    aliases: string[];
}
export interface Part {
    id: string;
    pn: string;
    name: string;
    aliases: string[];
    category: string;
    specs: string[];
    good: number | null;
    bad: number | null;
}
export interface Member {
    modelId: string;
    partId: string;
    membershipVersion?: string;
    rawPns?: string[];
    position: string;
    condition: string;
    source: string;
}
export interface Pending {
    id: string;
    modelId: string;
    rawPn: string;
    position: string;
    condition: string;
    source: string;
    reason: "unknown" | "ambiguous";
    candidateIds: string[];
}
export interface Catalog {
    version: 1;
    revision: number;
    models: Machine[];
    parts: Part[];
    members: Member[];
    pending: Pending[];
}
export interface SearchFilters {
    q: string;
    modelId: string;
    category: string;
    stock: "all" | "good" | "bad" | "zero" | "unknown";
}
export interface SearchResult {
    part: Part;
    members: Member[];
    reasons: string[];
}
export type ImportChoices = Record<number, {
    ignore?: boolean;
    partId?: string;
}>;
export interface ImportRow {
    line: number;
    rawPn: string;
    reviewDecision?: string;
    position: string;
    condition: string;
    source: string;
    status: "match" | "duplicate" | "ambiguous" | "unknown" | "pending" | "invalid" | "ignored";
    partId?: string;
    candidateIds: string[];
    note: string;
}
