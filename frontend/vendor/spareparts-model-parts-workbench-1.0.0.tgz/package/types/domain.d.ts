import type { Catalog, Machine } from "./types.ts";
export { searchCatalog } from "./search.ts";
export { applyImport, previewImport, resolvePending } from "./import.ts";
export declare function createModel(state: Catalog, input: Pick<Machine, "brand" | "name" | "aliases">): {
    modelId: string;
    state: {
        revision: number;
        models: Machine[];
        version: 1;
        parts: import("./types.ts").Part[];
        members: import("./types.ts").Member[];
        pending: import("./types.ts").Pending[];
    };
};
export declare function removeMember(state: Catalog, modelId: string, partId: string): Catalog;
