import { type FindCandidates } from "./operations";
import type { Part } from "./types";
export declare function errorText(error: unknown): string;
/** 确认期间禁用重复点击，关闭后不再用旧编辑器的回执切换页面。 */
export declare function useSubmission(): {
    busy: boolean;
    error: string;
    setError: import("react").Dispatch<import("react").SetStateAction<string>>;
    submit: <T>(write: () => Promise<T>, saved: (receipt: T) => void) => Promise<void>;
};
/** 仅在编辑器可见、并有有效筛选时进行目录联想；取消过期输入及已关闭弹窗。 */
export declare function useCandidateLookup(find: FindCandidates | undefined, query: string, active: boolean, exact?: string): {
    parts: Part[];
    busy: boolean;
    error: string;
    retry: () => void;
};
