import { type Commit } from "./operations";
import type { Catalog, Machine, Part, Pending, SearchResult } from "./types.ts";
export declare function shortModel(model: Machine): string;
export declare function ResultTable({ rows, catalog, modelId, queried, open }: {
    rows: SearchResult[];
    catalog: Catalog;
    modelId: string;
    queried: boolean;
    open: (part: Part) => void;
}): import("react").JSX.Element;
export declare function EmptyResults({ title, children }: {
    title: string;
    children?: React.ReactNode;
}): import("react").JSX.Element;
export declare function PendingList({ rows, catalog, onReview }: {
    rows: Pending[];
    catalog: Catalog;
    onReview?: (row: Pending) => void;
}): import("react").JSX.Element;
export declare function PartDetail({ part, catalog, result, onClose, onModel, commit, requireMembershipVersion, onMessage }: {
    part: Part;
    catalog: Catalog;
    result?: SearchResult;
    onClose: () => void;
    onModel: (id: string) => void;
    commit?: Commit;
    requireMembershipVersion: boolean;
    onMessage: (msg: string) => void;
}): import("react").JSX.Element;
