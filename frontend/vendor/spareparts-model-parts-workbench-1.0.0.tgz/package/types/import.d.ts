import type { Catalog, ImportChoices, ImportRow, Part } from "./types.ts";
export declare function previewImport(state: Catalog, modelId: string, text: string, choices?: ImportChoices, exactMatches?: ReadonlyMap<string, Part[]>): ImportRow[];
export declare function applyImport(state: Catalog, modelId: string, text: string, choices?: ImportChoices): {
    state: Catalog;
    added: number;
    pending: number;
    skipped: number;
};
export declare function resolvePending(state: Catalog, pendingId: string, partId: string, source: string): Catalog;
