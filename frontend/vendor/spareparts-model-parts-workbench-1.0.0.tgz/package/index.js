import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useRef, useState, useEffect, useMemo, useId, useCallback } from "react";
import { createPortal } from "react-dom";
import { RightOutlined, InboxOutlined, ApartmentOutlined, PlusOutlined, HddOutlined, FolderOpenOutlined, FileSearchOutlined, CheckCircleOutlined, CloseOutlined, AppstoreOutlined, SearchOutlined } from "@ant-design/icons";
const synonyms = [
  ["新华三", "华三", "h3c"],
  ["电源", "psu"],
  ["风扇", "fan"],
  ["主板", "motherboard"],
  ["网卡", "nic"],
  ["阵列卡", "raid卡"]
];
function key(text) {
  return text.normalize("NFKC").trim().toLowerCase();
}
function searchable(text) {
  return key(text).replace(/(\d)\s+(kw|w|gbps|gb|tb|gbe|ghz|mhz|mm)(?![a-z0-9])/g, "$1$2");
}
function escaped(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function extractModels(query, state) {
  const phrase = key(query);
  const identities = new Set(state.parts.flatMap((part) => [part.pn, ...part.aliases]).map(key));
  const spans = /* @__PURE__ */ new Map();
  for (const model of state.models) {
    for (const name of [model.name, ...model.aliases]) {
      const chunks = key(name).match(/[a-z]+|[0-9]+|[\p{Script=Han}]+|[^\s]/gu) ?? [];
      if (!chunks.length) continue;
      const pattern = new RegExp("(?<![a-z0-9._/+\\-])" + chunks.map(escaped).join("\\s*") + "(?![a-z0-9._/+\\-])", "gu");
      for (const match of phrase.matchAll(pattern)) {
        if (identities.has(key(match[0]))) continue;
        const start = match.index, end = start + match[0].length;
        const range = start + "/" + end;
        const span = spans.get(range) ?? { start, end, modelIds: /* @__PURE__ */ new Set() };
        span.modelIds.add(model.id);
        spans.set(range, span);
      }
    }
  }
  const constraints = [], remaining = [];
  let offset = 0;
  for (const span of [...spans.values()].sort((a, b) => a.start - b.start || b.end - a.end)) {
    if (span.start < offset) continue;
    remaining.push(phrase.slice(offset, span.start));
    constraints.push(span.modelIds);
    offset = span.end;
  }
  remaining.push(phrase.slice(offset));
  return { constraints, remaining: remaining.join(" ") };
}
function queryTerms(query, state) {
  const dictionary = /* @__PURE__ */ new Set([
    ...synonyms.flat(),
    ...state.models.map((model) => key(model.brand)),
    ...state.parts.map((part) => key(part.category))
  ]);
  const chinese = [...dictionary].filter((word) => /^\p{Script=Han}+$/u.test(word)).sort((a, b) => b.length - a.length);
  const phrase = searchable(query).replace(/\bpower\s+supply\b/g, "psu");
  const runs = phrase.match(/[\p{Script=Han}]+|[a-z0-9][a-z0-9._/+\-]*/gu) ?? [];
  const terms = [];
  for (const run of runs) {
    if (!/^\p{Script=Han}/u.test(run)) {
      terms.push(run);
      continue;
    }
    let literal = "";
    for (let i = 0; i < run.length; ) {
      const word = chinese.find((item) => run.startsWith(item, i));
      if (!word) {
        literal += run[i++];
        continue;
      }
      if (literal) terms.push(literal);
      literal = "";
      terms.push(word);
      i += word.length;
    }
    if (literal) terms.push(literal);
  }
  return [...new Set(terms)];
}
function inStock(part, stock) {
  switch (stock) {
    case "all":
      return true;
    case "good":
      return part.good !== null && part.good > 0;
    case "bad":
      return part.bad !== null && part.bad > 0;
    case "zero":
      return part.good === 0 && part.bad === 0;
    case "unknown":
      return part.good === null || part.bad === null;
  }
}
function textMatches(text, term) {
  const value = searchable(text);
  if (/\d/.test(term)) {
    return new RegExp("(?<![0-9])" + escaped(term) + "(?![0-9])", "u").test(value);
  }
  return value.includes(term);
}
function memberIdentity(term, member) {
  const raw = member.rawPns?.find((pn) => key(pn) === term);
  return raw ? { rank: 3, reason: "机型清单原号 · " + raw } : void 0;
}
function matchTerm(term, part, model, member, localOnly) {
  const pn = key(part.pn);
  if (pn === term) return { rank: 4, reason: "标准 PN 精确匹配" };
  const alias = part.aliases.find((item) => key(item) === term);
  if (alias) return { rank: 3, reason: "PN 别名 · " + alias };
  const local = memberIdentity(term, member);
  if (local || localOnly.has(term)) return local;
  if (pn.startsWith(term)) return { rank: 2, reason: "标准 PN 前缀" };
  const variations = synonyms.find((group) => group.includes(term)) ?? [term];
  const matches = (value) => variations.some((word) => textMatches(value, word));
  const fields = [
    ["品牌", [model.brand]],
    ["机型", [model.name]],
    ["机型别名", model.aliases],
    ["部件", [part.category]],
    ["规格", part.specs],
    ["描述", [part.name]],
    ["部位", [member.position]],
    ["配置", [member.condition]],
    ["来源", [member.source]]
  ];
  for (const [label, values] of fields) {
    const value = values.find(matches);
    if (value) return { rank: 1, reason: label + " · " + value };
  }
  return void 0;
}
function matchGroup(group, part, model, member, localOnly) {
  if (group.literal === key(part.pn)) return [{ rank: 4, reason: "标准 PN 精确匹配" }];
  const exactAlias = part.aliases.find((alias) => group.literal === key(alias));
  if (exactAlias) return [{ rank: 3, reason: "PN 别名 · " + exactAlias }];
  const raw = memberIdentity(group.literal, member);
  if (raw) return [raw];
  if (localOnly.has(group.literal)) return void 0;
  if (group.literal && !group.terms.length && !group.constraints.length) return void 0;
  if (group.constraints.some((ids) => !ids.has(model.id))) return void 0;
  const evidence = [];
  if (group.constraints.length) evidence.push({ rank: 1, reason: "机型 · " + model.name });
  for (const term of group.terms) {
    const match = matchTerm(term, part, model, member, localOnly);
    if (!match) return void 0;
    evidence.push(match);
  }
  return evidence;
}
function searchCatalog(state, filters) {
  const query = key(filters.q);
  const alternatives = query.includes("|") ? query.split("|").map((item) => item.trim()).filter(Boolean) : [query];
  const groups = [];
  for (const alternative of alternatives) {
    if (!alternative) {
      groups.push({ literal: "", constraints: [], terms: [] });
      continue;
    }
    const { constraints, remaining } = extractModels(alternative, state);
    const terms = queryTerms(remaining, state);
    groups.push({ literal: alternative, constraints, terms });
  }
  if (!groups.length) return [];
  const models = new Map(state.models.map((model) => [model.id, model]));
  const parts = new Map(state.parts.map((part) => [part.id, part]));
  const globalIds = new Set(state.parts.flatMap((p) => [p.pn, ...p.aliases]).map(key));
  const localOnly = new Set(state.members.flatMap((m) => m.rawPns ?? []).map(key).filter((pn) => !globalIds.has(pn)));
  const hits = /* @__PURE__ */ new Map();
  for (const member of state.members) {
    if (filters.modelId && member.modelId !== filters.modelId) continue;
    const model = models.get(member.modelId);
    const part = parts.get(member.partId);
    if (!model || !part || filters.category && part.category !== filters.category || !inStock(part, filters.stock)) continue;
    const matches = groups.map((group) => matchGroup(group, part, model, member, localOnly)).filter((match) => match !== void 0);
    if (!matches.length) continue;
    const evidence = matches.flat();
    const rank = Math.max(0, ...evidence.map((item) => item.rank));
    const hit = hits.get(part.id) ?? { part, members: [], reasons: [], rank: 0 };
    hit.rank = Math.max(hit.rank, rank);
    hit.members.push(member);
    hit.reasons = [.../* @__PURE__ */ new Set([...hit.reasons, ...evidence.map((item) => item.reason)])];
    hits.set(part.id, hit);
  }
  return [...hits.values()].sort((a, b) => b.rank - a.rank || (query ? a.part.pn.localeCompare(b.part.pn, "en") : 0)).map(({ part, members, reasons }) => ({ part, members, reasons }));
}
function validMembershipVersion(value) {
  return typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
}
function exactPartsByPn(pns, reply) {
  const failure = "主库返回的 PN 匹配信息不完整，请重试查询。";
  if (!reply.matches || !Array.isArray(reply.parts)) throw new Error(failure);
  const parts = new Map(reply.parts.map((part) => [part.id, part]));
  const matched = /* @__PURE__ */ new Map();
  for (const input of pns) {
    const pn = key(input);
    if (matched.has(pn)) continue;
    if (!Object.prototype.hasOwnProperty.call(reply.matches, pn)) throw new Error(failure);
    const ids = reply.matches[pn];
    if (!Array.isArray(ids) || new Set(ids).size !== ids.length) throw new Error(failure);
    matched.set(pn, ids.map((id) => {
      const part = parts.get(id);
      if (!part) throw new Error(failure);
      return part;
    }));
  }
  return matched;
}
function commandBody(action) {
  if (action.action !== "import") return { ...action };
  return {
    action: "import",
    modelId: action.modelId,
    rows: action.rows.map((row) => ({
      line: row.line,
      rawPn: row.rawPn,
      position: row.position,
      condition: row.condition,
      source: row.source,
      reviewDecision: row.reviewDecision,
      ignore: ["ignored", "invalid", "duplicate", "pending"].includes(row.status),
      partId: action.choices[row.line]?.partId ?? (row.status === "match" ? row.partId : void 0),
      candidateIds: row.candidateIds
    }))
  };
}
function errorText(error) {
  return error instanceof Error ? error.message : "请求未完成，请稍后重试。";
}
function useSubmission() {
  const mounted = useRef(false);
  const lock = useRef(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  async function submit(write, saved) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      const result = await write();
      if (mounted.current) saved(result);
    } catch (cause) {
      if (mounted.current) setError(errorText(cause));
    } finally {
      lock.current = false;
      if (mounted.current) setBusy(false);
    }
  }
  return { busy, error, setError, submit };
}
function useCandidateLookup(find, query, active, exact) {
  const input = exact ?? query.trim();
  const [attempt, setAttempt] = useState(0);
  const [result, setResult] = useState(null);
  const key$1 = attempt + "/" + (exact === void 0 ? "search:" : "pn:") + input;
  useEffect(() => {
    if (!find || !active || !input) return;
    const controller = new AbortController();
    setResult(null);
    const timer = window.setTimeout(async () => {
      try {
        const response = await find(exact === void 0 ? { q: input } : { pns: [input] }, controller.signal);
        if (controller.signal.aborted) return;
        const parts = exact === void 0 ? response.parts : exactPartsByPn([input], response).get(key(input));
        setResult({ key: key$1, parts, error: "" });
      } catch (cause) {
        if (!controller.signal.aborted) setResult({ key: key$1, parts: [], error: errorText(cause) });
      }
    }, exact === void 0 ? 180 : 0);
    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [find, active, key$1, input, exact]);
  const match = active && result?.key === key$1 ? result : null;
  return {
    parts: match?.parts ?? [],
    busy: Boolean(find && active && input && !match),
    error: match?.error ?? "",
    retry: () => setAttempt((previous) => previous + 1)
  };
}
function readClipboard(text) {
  const input = text.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
  const result = [];
  let line = 1, start = 1;
  let cells = [], field = "", quoted = false, closed = false, error = "";
  function finishRow() {
    cells.push(field.trim());
    if (error || cells.some(Boolean)) result.push({ line: start, cells, error });
    cells = [];
    field = "";
    closed = false;
    error = "";
  }
  for (let i = 0; i < input.length; i++) {
    const char = input[i];
    if (quoted) {
      if (char === '"') {
        if (input[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          quoted = false;
          closed = true;
        }
      } else {
        field += char;
        if (char === "\n") line++;
      }
    } else if (char === "	") {
      cells.push(field.trim());
      field = "";
      closed = false;
    } else if (char === "\n") {
      finishRow();
      start = ++line;
    } else if (char === '"' && !field && !closed) {
      quoted = true;
    } else {
      if (closed && char.trim()) error = "带引号的单元格后有多余内容";
      field += char;
    }
  }
  if (quoted) error = "有一个单元格的引号未闭合";
  finishRow();
  return result;
}
const headerNames = {
  rawPn: ["pn", "备件pn", "料号", "备件料号", "原文编号"],
  position: ["部件", "部位", "位置", "部件位置", "安装位置"],
  condition: ["配置", "适用配置", "条件", "适用配置或位置"],
  source: ["来源", "依据", "核对依据", "核对依据与版本", "来源版本", "来源/版本", "来源与版本"],
  reviewDecision: ["核对结果", "核对结论"]
};
function columnLayout(first) {
  const headers = first?.cells.map((name) => key(name).replace(/\s+/g, "")) ?? [];
  const indices = Object.fromEntries(Object.entries(headerNames).map(([field, names]) => [
    field,
    headers.findIndex((name) => names.includes(name))
  ]));
  return indices.rawPn >= 0 && !first?.error ? indices : null;
}
function ensureModel(state, modelId) {
  if (!state.models.some((model) => model.id === modelId)) throw new Error("请先选择一个机型");
}
function previewImport(state, modelId, text, choices = {}, exactMatches) {
  ensureModel(state, modelId);
  const lines = readClipboard(text);
  const header = columnLayout(lines[0]);
  if (header) lines.shift();
  const columns = header ?? { rawPn: 0, position: 1, condition: 2, source: 3 };
  const scoped = state.members.filter((m) => m.modelId === modelId);
  const members = new Set(scoped.map((m) => m.partId));
  const confirmedRaw = /* @__PURE__ */ new Map();
  for (const member of scoped) {
    for (const raw of member.rawPns ?? []) {
      const id = key(raw);
      const ids = confirmedRaw.get(id) ?? [];
      if (!ids.includes(member.partId)) ids.push(member.partId);
      confirmedRaw.set(id, ids);
    }
  }
  const waiting = new Set(state.pending.filter((p) => p.modelId === modelId).map((p) => key(p.rawPn)));
  const batchParts = /* @__PURE__ */ new Set(), batchRaw = /* @__PURE__ */ new Set();
  return lines.map(({ line, cells, error }) => {
    const rawPn = cells[columns.rawPn] ?? "";
    const input = key(rawPn);
    const reviewDecision = header && header.reviewDecision >= 0 ? cells[header.reviewDecision] ?? "" : void 0;
    const base = {
      line,
      rawPn,
      position: cells[columns.position] ?? "",
      condition: cells[columns.condition] ?? "",
      source: cells[columns.source] ?? "",
      candidateIds: [],
      reviewDecision
    };
    if (reviewDecision !== void 0 && reviewDecision !== "确认纳入") {
      return { ...base, status: "ignored", note: "请先在源表标记「确认纳入」，再粘贴预览" };
    }
    if (choices[line]?.ignore) return { ...base, status: "ignored", note: "本次跳过" };
    if (error || !rawPn || !header && cells.slice(4).some(Boolean)) {
      return { ...base, status: "invalid", note: error || (!rawPn ? "缺少 PN" : "无表头时请按 PN、部位、适用配置、来源四列粘贴") };
    }
    let candidates = exactMatches?.get(input);
    if (!exactMatches) {
      const exact = state.parts.filter((part) => key(part.pn) === input);
      candidates = exact.length ? exact : state.parts.filter((part) => part.aliases.some((alias) => key(alias) === input));
    }
    if (!candidates) throw new Error("主库缺少该 PN 的匹配结果，请重新预览。");
    const candidateIds = candidates.map((part) => part.id);
    const choice = choices[line]?.partId;
    if (choice && !candidateIds.includes(choice)) {
      return { ...base, candidateIds, status: "invalid", note: "所选档案与此行 PN 不匹配，请重新核对" };
    }
    const prior = confirmedRaw.get(input);
    if (prior && !choice) {
      const pns = prior.map((id) => state.parts.find((part) => part.id === id)?.pn ?? id);
      return { ...base, candidateIds, partId: prior.length === 1 ? prior[0] : void 0, status: "duplicate", note: "此原号已在本机型核定为 " + pns.join("、") };
    }
    const partId = choice ?? (candidates.length === 1 ? candidates[0].id : void 0);
    const row = { ...base, partId, candidateIds };
    if (waiting.has(input)) return { ...row, status: "pending", note: "已在本机型待核清单" };
    if (partId ? batchParts.has(partId) : batchRaw.has(input)) {
      return { ...row, status: "duplicate", note: "与本批前一行重复" };
    }
    batchRaw.add(input);
    if (partId) batchParts.add(partId);
    if (partId && members.has(partId)) return { ...row, status: "duplicate", note: "已在本机型池中" };
    if (!partId) {
      return candidates.length ? { ...row, status: "ambiguous", note: "别名对应多个档案" } : { ...row, status: "unknown", note: "档案中未找到此 PN" };
    }
    const isStandard = candidates.some((part) => part.id === partId && key(part.pn) === input);
    const note = isStandard ? "标准 PN 精确匹配" : choice ? "已选择对应的档案" : "按原号匹配档案";
    return { ...row, status: "match", note };
  });
}
function Dialog({ title, subtitle, wide, className = "", children, onClose }) {
  const ref = useRef(null);
  const titleId = useId();
  const descriptionId = useId();
  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    const tree = dialog.getRootNode();
    const trigger = tree instanceof ShadowRoot ? tree.activeElement : document.activeElement;
    dialog.showModal();
    const focusTarget = dialog.querySelector("[data-dialog-focus]");
    focusTarget?.focus({ preventScroll: true });
    return () => {
      dialog.close();
      if (trigger instanceof HTMLElement && trigger.isConnected) trigger.focus({ preventScroll: true });
    };
  }, []);
  return /* @__PURE__ */ jsxs(
    "dialog",
    {
      ref,
      "aria-labelledby": titleId,
      "aria-describedby": subtitle ? descriptionId : void 0,
      className: `ppe-dialog ${wide ? "ppe-wide" : ""} ${className}`,
      onCancel: (event) => {
        event.preventDefault();
        onClose();
      },
      onClick: (event) => {
        if (event.target !== event.currentTarget) return;
        const bounds = event.currentTarget.getBoundingClientRect();
        if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) onClose();
      },
      children: [
        /* @__PURE__ */ jsxs("header", { className: "ppe-dialog-head", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h2", { id: titleId, children: title }),
            subtitle && /* @__PURE__ */ jsx("p", { id: descriptionId, children: subtitle })
          ] }),
          /* @__PURE__ */ jsx("button", { type: "button", className: "ppe-x", "aria-label": "关闭弹窗", onClick: onClose, children: "×" })
        ] }),
        children
      ]
    }
  );
}
function ModelEditor({ state, onClose, commit, onSaved }) {
  const [brand, setBrand] = useState("");
  const [name, setName] = useState("");
  const [aliases, setAliases] = useState("");
  const [revision, setRevision] = useState(state.revision);
  const saving = useSubmission();
  function submit(event) {
    event.preventDefault();
    if (state.revision !== revision) return;
    const input = { brand: brand.trim(), name: name.trim(), aliases: aliases.split(/[、，,；;\n]+/u).map((alias) => alias.trim()).filter(Boolean) };
    void saving.submit(
      () => commit({ action: "create", ...input }, revision),
      (receipt) => onSaved("已新建机型 " + input.name, receipt.modelId)
    );
  }
  return /* @__PURE__ */ jsx(Dialog, { title: "新建机型", onClose: () => {
    if (!saving.busy) onClose();
  }, children: /* @__PURE__ */ jsxs("form", { onSubmit: submit, className: "ppe-form", children: [
    /* @__PURE__ */ jsxs("div", { className: "ppe-body ppe-fields", children: [
      /* @__PURE__ */ jsxs("label", { children: [
        "品牌",
        /* @__PURE__ */ jsx("input", { "data-dialog-focus": true, required: true, value: brand, onChange: (e) => setBrand(e.target.value), placeholder: "例如 华三" })
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        "正式型号",
        /* @__PURE__ */ jsx("input", { required: true, value: name, onChange: (e) => setName(e.target.value), placeholder: "例如 H3C UniServer R6900 G3" })
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        "搜索别名 ",
        /* @__PURE__ */ jsx("small", { children: "选填" }),
        /* @__PURE__ */ jsx("textarea", { value: aliases, rows: 2, onChange: (e) => setAliases(e.target.value), placeholder: "例如 华三 6900G3，R6900 G3" }),
        /* @__PURE__ */ jsx("span", { className: "ppe-help", children: "多个名称可用逗号或换行分隔。" })
      ] }),
      revision !== state.revision && /* @__PURE__ */ jsxs("p", { className: "ppe-error", children: [
        "目录资料已有更新。 ",
        /* @__PURE__ */ jsx("button", { type: "button", className: "ppe-text-action", onClick: () => setRevision(state.revision), children: "核对最新目录后继续" })
      ] }),
      saving.error && /* @__PURE__ */ jsx("p", { role: "alert", className: "ppe-error", children: saving.error })
    ] }),
    /* @__PURE__ */ jsxs("footer", { className: "ppe-footer", children: [
      /* @__PURE__ */ jsx("button", { type: "button", className: "btn subtle", disabled: saving.busy, onClick: onClose, children: "取消" }),
      /* @__PURE__ */ jsx("button", { className: "btn primary", disabled: saving.busy || revision !== state.revision, type: "submit", children: saving.busy ? "正在保存…" : "创建机型" })
    ] })
  ] }) });
}
function normalize(text) {
  return text.normalize("NFKC").toUpperCase().trim();
}
function matchParts(parts, query) {
  const terms = normalize(query).split(/\s+/u).filter(Boolean);
  return parts.filter((part) => {
    const text = normalize([part.pn, ...part.aliases, part.name, part.category, ...part.specs].join(" "));
    return terms.every((term) => text.includes(term));
  });
}
const impact = {
  match: "可加入",
  duplicate: "重复",
  ambiguous: "多档匹配",
  unknown: "未找到档案",
  pending: "已在待核",
  invalid: "格式有误",
  ignored: "已跳过"
};
function canPick(row) {
  const approved = row.reviewDecision === void 0 || row.reviewDecision === "确认纳入";
  return approved && ["match", "unknown", "ambiguous", "ignored"].includes(row.status);
}
function ImportEditor({ state, modelId, onClose, commit, findCandidates, examples, onSaved }) {
  const [tab, setTab] = useState("paste");
  const [query, setQuery] = useState("");
  const [input, setInput] = useState("");
  const [revision, setRevision] = useState(null);
  const [choices, setChoices] = useState({});
  const saving = useSubmission();
  const { error, setError } = saving;
  const [previewing, setPreviewing] = useState(false);
  const [batch, setBatch] = useState(null);
  const lookup = useCandidateLookup(findCandidates, query, tab === "search" && revision === null);
  const active = useRef(null);
  useEffect(() => () => active.current?.abort(), []);
  const model = state.models.find((item) => item.id === modelId);
  const parts = useMemo(() => new Map([...state.parts, ...batch?.parts ?? []].map((part) => [part.id, part])), [state.parts, batch]);
  const options = useMemo(() => findCandidates ? lookup.parts : matchParts(state.parts, query), [findCandidates, lookup.parts, state.parts, query]);
  const memberIds = new Set(state.members.filter((row) => row.modelId === modelId).map((row) => row.partId));
  const selectedPns = new Set(input.split(/\r?\n/u).map((line) => normalize(line.split("	")[0])));
  const original = useMemo(() => revision === null ? [] : previewImport(state, modelId, input, {}, batch?.matches), [revision, state, modelId, input, batch]);
  const rows = useMemo(() => revision === null ? [] : previewImport(state, modelId, input, choices, batch?.matches), [revision, state, modelId, input, choices, batch]);
  const reviewDraft = useMemo(() => tab === "search" && /核对结果|核对结论/u.test(input) && model ? previewImport(state, modelId, input).some((row) => row.reviewDecision !== void 0) : false, [tab, input, model, state, modelId]);
  const originalByLine = new Map(original.map((row) => [row.line, row]));
  const added = rows.filter((row) => row.status === "match").length;
  const pending = rows.filter((row) => row.status === "unknown" || row.status === "ambiguous").length;
  const skipped = rows.length - added - pending;
  const stale = revision !== null && revision !== state.revision;
  const previewHeading = useRef(null);
  const pasteBox = useRef(null);
  const searchBox = useRef(null);
  useEffect(() => {
    if (revision !== null) previewHeading.current?.focus();
  }, [revision]);
  function reviseText(value) {
    active.current?.abort();
    setPreviewing(false);
    setInput(value);
    setChoices({});
    setError("");
  }
  async function preview() {
    active.current?.abort();
    const request = new AbortController();
    active.current = request;
    setPreviewing(true);
    setError("");
    try {
      if (!model) throw new Error("当前机型已不存在，请重新选择机型。");
      const parsed = previewImport({ ...state, parts: [] }, modelId, input);
      if (!parsed.length) throw new Error("请先选择备件，或输入至少一个 PN。");
      if (findCandidates) {
        if (parsed.length > 1e3) throw new Error("每批最多 1000 行，请将清单分批预览。");
        const pns = [...new Set(parsed.filter((row) => !["ignored", "invalid"].includes(row.status)).map((row) => row.rawPn))];
        const result = pns.length ? await findCandidates({ pns }, request.signal) : { parts: [], matches: {} };
        if (request.signal.aborted) return;
        setBatch({ parts: result.parts, matches: exactPartsByPn(pns, result) });
      }
      setRevision(state.revision);
    } catch (cause) {
      if (!request.signal.aborted) setError(errorText(cause));
    } finally {
      if (!request.signal.aborted) setPreviewing(false);
    }
  }
  function pick(line, value) {
    setError("");
    setChoices((current) => ({ ...current, [line]: { ...current[line], ...value } }));
  }
  function save() {
    if (revision === null || stale) return;
    void saving.submit(() => commit({ action: "import", modelId, text: input, choices, rows }, revision), (result) => {
      if (result.added === void 0 || result.pending === void 0 || result.skipped === void 0) {
        onSaved("清单已提交。请刷新清单核对处理结果。");
      } else onSaved(`已加入 ${result.added} 条，保存待核 ${result.pending} 条，跳过 ${result.skipped} 条。`);
    });
  }
  function previous() {
    setRevision(null);
    setError("");
    requestAnimationFrame(() => (pasteBox.current ?? searchBox.current)?.focus());
  }
  return /* @__PURE__ */ jsxs(Dialog, { title: revision === null ? "添加备件 PN" : "核对入池清单", subtitle: model?.name, wide: true, onClose: () => {
    if (!saving.busy) onClose();
  }, children: [
    /* @__PURE__ */ jsxs("div", { className: "ppe-body", children: [
      revision === null ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "ppe-segment", role: "group", "aria-label": "添加方式", children: [
          /* @__PURE__ */ jsx("button", { type: "button", "aria-pressed": tab === "paste", onClick: () => setTab("paste"), children: "粘贴清单" }),
          /* @__PURE__ */ jsx("button", { type: "button", "aria-pressed": tab === "search", onClick: () => setTab("search"), children: "搜索 PN 档案" })
        ] }),
        tab === "paste" ? /* @__PURE__ */ jsxs("div", { className: "ppe-fields", children: [
          /* @__PURE__ */ jsxs("label", { children: [
            "PN 清单",
            /* @__PURE__ */ jsx(
              "textarea",
              {
                ref: pasteBox,
                "data-dialog-focus": true,
                rows: 7,
                value: input,
                spellCheck: false,
                onChange: (e) => reviseText(e.target.value),
                placeholder: "每行一个 PN，或直接粘贴 Excel 四列\nPN　部位　适用配置　来源"
              }
            )
          ] }),
          /* @__PURE__ */ jsx("p", { className: "ppe-input-tip", children: "可直接粘贴 Excel 单元格。带「核对结果」列时，仅「确认纳入」的行参与匹配。" }),
          examples && !input.trim() && /* @__PURE__ */ jsxs("div", { className: "ppe-input-examples", children: [
            /* @__PURE__ */ jsx("button", { className: "ppe-text-action", type: "button", onClick: () => {
              reviseText(examples.paste);
              pasteBox.current?.focus();
            }, children: "填入示例" }),
            /* @__PURE__ */ jsx("button", { className: "ppe-text-action", type: "button", onClick: () => {
              reviseText(examples.sheet);
              pasteBox.current?.focus();
            }, children: "填入核对表示例" })
          ] })
        ] }) : /* @__PURE__ */ jsxs("div", { className: "ppe-fields", children: [
          reviewDraft && /* @__PURE__ */ jsx("p", { className: "ppe-sheet-hint", children: "当前清单带有核对结论。请先预览这张表，手选的备件可以另开一批。" }),
          /* @__PURE__ */ jsxs("label", { children: [
            "搜索备件档案",
            /* @__PURE__ */ jsx("input", { ref: searchBox, type: "search", value: query, onChange: (e) => setQuery(e.target.value), placeholder: "输入 PN、别名或部件名称" })
          ] }),
          /* @__PURE__ */ jsxs("ul", { className: "ppe-picker", "aria-label": "可选择的 PN 档案", children: [
            options.map((part) => {
              const member = memberIds.has(part.id), chosen = selectedPns.has(normalize(part.pn));
              return /* @__PURE__ */ jsxs("li", { children: [
                /* @__PURE__ */ jsxs("span", { children: [
                  /* @__PURE__ */ jsx("b", { className: "ppe-pn", children: part.pn }),
                  /* @__PURE__ */ jsx("span", { className: "ppe-option-name", children: part.name })
                ] }),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    className: "btn subtle ppe-pick",
                    disabled: member || chosen || reviewDraft,
                    "aria-label": `${member ? "已在池中" : chosen ? "已选" : "选择"} ${part.pn}`,
                    onClick: () => reviseText(input ? `${input}${input.endsWith("\n") ? "" : "\n"}${part.pn}` : part.pn),
                    children: member ? "已在池中" : chosen ? "已选" : "选择"
                  }
                )
              ] }, part.id);
            }),
            lookup.busy && /* @__PURE__ */ jsx("li", { className: "ppe-noresult", role: "status", children: "正在查询备件档案…" }),
            lookup.error && /* @__PURE__ */ jsxs("li", { className: "ppe-noresult", role: "alert", children: [
              lookup.error,
              " ",
              /* @__PURE__ */ jsx("button", { type: "button", className: "ppe-text-action", onClick: lookup.retry, children: "重试查询" })
            ] }),
            !options.length && !lookup.busy && !lookup.error && /* @__PURE__ */ jsx("li", { className: "ppe-noresult", children: findCandidates && !query.trim() ? "输入 PN、别名或部件名称查找档案。" : "没有匹配档案，可将原始编号粘贴到清单，保存为待核。" })
          ] }),
          !!input.trim() && /* @__PURE__ */ jsx("button", { className: "ppe-text-action", type: "button", onClick: () => setTab("paste"), children: "查看已选清单" })
        ] })
      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("h3", { className: "ppe-section-title", ref: previewHeading, tabIndex: -1, children: "导入预览" }),
        /* @__PURE__ */ jsxs("div", { className: "ppe-counts", "aria-live": "polite", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            /* @__PURE__ */ jsx("b", { children: added }),
            " 条加入"
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            /* @__PURE__ */ jsx("b", { children: pending }),
            " 条待核"
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            /* @__PURE__ */ jsx("b", { children: skipped }),
            " 条跳过"
          ] })
        ] }),
        rows.some((row) => row.reviewDecision !== void 0) && /* @__PURE__ */ jsx("p", { className: "ppe-sheet-hint", children: "已读取源表核对结果。如需改变结论，请先核实并修改源表，再粘贴预览。" }),
        /* @__PURE__ */ jsx("ol", { className: "ppe-preview", "aria-label": "逐行匹配结果", children: rows.map((row) => {
          const originalRow = originalByLine.get(row.line) ?? row;
          const choice = choices[row.line];
          const matched = row.partId ? parts.get(row.partId) : void 0;
          const provenance = [row.position, row.condition, row.source].filter(Boolean).join(" · ");
          return /* @__PURE__ */ jsxs("li", { children: [
            /* @__PURE__ */ jsxs("div", { className: "ppe-preview-main", children: [
              /* @__PURE__ */ jsxs("label", { className: "ppe-row-check", children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "checkbox",
                    "aria-label": `包含第 ${row.line} 行 ${row.rawPn}`,
                    disabled: !canPick(row),
                    checked: canPick(row) && row.status !== "ignored",
                    onChange: (e) => pick(row.line, { ignore: !e.target.checked })
                  }
                ),
                /* @__PURE__ */ jsxs("span", { className: "ppe-line-number", children: [
                  "第 ",
                  row.line,
                  " 行"
                ] }),
                /* @__PURE__ */ jsx("strong", { className: "ppe-pn", children: row.rawPn || "空编号" })
              ] }),
              /* @__PURE__ */ jsx("span", { className: `ppe-status ppe-${row.status}`, children: impact[row.status] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "ppe-row-detail", children: [
              row.reviewDecision !== void 0 && /* @__PURE__ */ jsxs("span", { className: "ppe-source-decision", children: [
                "源表核对结果 ",
                /* @__PURE__ */ jsx("strong", { children: row.reviewDecision || "空白" })
              ] }),
              matched && /* @__PURE__ */ jsxs("span", { className: "ppe-matched", children: [
                matched.name,
                normalize(matched.pn) !== normalize(row.rawPn) && ` · ${matched.pn}`
              ] }),
              row.note && /* @__PURE__ */ jsx("span", { className: "ppe-help", children: row.note }),
              provenance && /* @__PURE__ */ jsx("span", { className: "ppe-evidence", children: provenance }),
              originalRow.candidateIds.length > 1 && /* @__PURE__ */ jsxs("label", { className: "ppe-resolve", children: [
                "匹配到的档案",
                /* @__PURE__ */ jsxs(
                  "select",
                  {
                    value: choice?.partId || "",
                    disabled: row.status === "ignored",
                    "aria-label": `第 ${row.line} 行匹配档案`,
                    onChange: (e) => pick(row.line, { partId: e.target.value || void 0 }),
                    children: [
                      /* @__PURE__ */ jsx("option", { value: "", children: "保留为待核" }),
                      originalRow.candidateIds.map((id) => /* @__PURE__ */ jsxs("option", { value: id, children: [
                        parts.get(id)?.pn,
                        " · ",
                        parts.get(id)?.name
                      ] }, id))
                    ]
                  }
                )
              ] })
            ] })
          ] }, row.line);
        }) }),
        stale && /* @__PURE__ */ jsx("p", { className: "ppe-error", role: "alert", children: "目录资料已有更新，请重新预览。" })
      ] }),
      error && /* @__PURE__ */ jsx("p", { role: "alert", className: "ppe-error", children: error })
    ] }),
    /* @__PURE__ */ jsx("footer", { className: "ppe-footer", children: revision === null ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("button", { type: "button", className: "btn subtle", onClick: onClose, children: "取消" }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "btn primary", disabled: !input.trim() || previewing, onClick: preview, children: previewing ? "正在匹配…" : "预览清单" })
    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("button", { type: "button", className: "btn subtle", disabled: saving.busy || previewing, onClick: previous, children: "返回编辑" }),
      stale ? /* @__PURE__ */ jsx("button", { type: "button", className: "btn primary", disabled: previewing, onClick: preview, children: previewing ? "正在匹配…" : "重新预览" }) : /* @__PURE__ */ jsx("button", { type: "button", className: "btn primary", disabled: added + pending === 0 || saving.busy, onClick: save, children: saving.busy ? "正在保存…" : pending && !added ? "保存待核" : pending ? "确认保存清单" : "确认加入" })
    ] }) })
  ] });
}
function PendingEditor({ state, row, onClose, commit, findCandidates, onSaved }) {
  const [partId, setPartId] = useState("");
  const [source, setSource] = useState(row.source);
  const [query, setQuery] = useState("");
  const [revision, setRevision] = useState(state.revision);
  const saving = useSubmission();
  const ambiguous = row.reason === "ambiguous";
  const exact = useCandidateLookup(findCandidates, "", true, row.rawPn);
  const historic = useMemo(() => state.parts.filter((part) => row.candidateIds.includes(part.id)), [state.parts, row.candidateIds]);
  const restricted = findCandidates ? exact.parts.length ? exact.parts : void 0 : ambiguous ? historic : void 0;
  const allowSearch = Boolean(findCandidates && !exact.busy && !exact.error && !restricted);
  const search = useCandidateLookup(findCandidates, query, allowSearch);
  const busy = exact.busy || search.busy;
  const lookupError = exact.error || search.error;
  const options = useMemo(() => {
    if (busy || lookupError) return [];
    if (restricted) return matchParts(restricted, query);
    return findCandidates ? search.parts : matchParts(state.parts, query);
  }, [restricted, busy, lookupError, findCandidates, search.parts, state.parts, query]);
  const listId = useId();
  function confirm(event) {
    event.preventDefault();
    if (!options.some((part) => part.id === partId) || !source.trim() || revision !== state.revision) return;
    void saving.submit(
      () => commit({ action: "resolve", pendingId: row.id, partId, source: source.trim() }, revision),
      () => onSaved(`已确认 ${row.rawPn} 的机型归属。`)
    );
  }
  const model = state.models.find((item) => item.id === row.modelId);
  return /* @__PURE__ */ jsx(Dialog, { title: "核对备件归属", subtitle: model?.name, onClose: () => {
    if (!saving.busy) onClose();
  }, children: /* @__PURE__ */ jsxs("form", { onSubmit: confirm, className: "ppe-form", children: [
    /* @__PURE__ */ jsxs("div", { className: "ppe-body ppe-fields", children: [
      /* @__PURE__ */ jsxs("dl", { className: "ppe-pending-meta", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("dt", { children: "原始编号" }),
          /* @__PURE__ */ jsx("dd", { className: "ppe-pn", children: row.rawPn })
        ] }),
        row.position && /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("dt", { children: "部位" }),
          /* @__PURE__ */ jsx("dd", { children: row.position })
        ] }),
        row.condition && /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("dt", { children: "适用配置" }),
          /* @__PURE__ */ jsx("dd", { children: row.condition })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        "筛选可选档案",
        /* @__PURE__ */ jsx("input", { type: "search", value: query, onChange: (e) => {
          setQuery(e.target.value);
          setPartId("");
        }, placeholder: "搜索 PN 或部件名称", "data-dialog-focus": true })
      ] }),
      /* @__PURE__ */ jsxs("label", { htmlFor: listId, children: [
        "归属 PN",
        /* @__PURE__ */ jsxs("select", { id: listId, required: true, value: partId, onChange: (e) => setPartId(e.target.value), children: [
          /* @__PURE__ */ jsx("option", { value: "", children: "请选择档案" }),
          options.map((part) => /* @__PURE__ */ jsxs("option", { value: part.id, children: [
            part.pn,
            " · ",
            part.name
          ] }, part.id))
        ] }),
        busy && /* @__PURE__ */ jsx("span", { className: "ppe-help", role: "status", children: "正在查询备件档案…" }),
        lookupError && /* @__PURE__ */ jsxs("span", { className: "ppe-error", role: "alert", children: [
          lookupError,
          " ",
          /* @__PURE__ */ jsx("button", { type: "button", className: "ppe-text-action", onClick: exact.error ? exact.retry : search.retry, children: "重试查询" })
        ] }),
        !options.length && !busy && !lookupError && /* @__PURE__ */ jsx("span", { className: "ppe-help", children: allowSearch && !query.trim() ? "请输入编号或部件名称查找对应的档案。" : "没有匹配档案，可以保留原始待核行。" })
      ] }),
      /* @__PURE__ */ jsxs("label", { children: [
        "核对依据",
        /* @__PURE__ */ jsx("input", { required: true, value: source, onChange: (e) => setSource(e.target.value), placeholder: "填写备件表的版本、页码或拆机记录" })
      ] }),
      revision !== state.revision && /* @__PURE__ */ jsxs("p", { className: "ppe-error", children: [
        "目录资料已有更新。 ",
        /* @__PURE__ */ jsx("button", { type: "button", className: "ppe-text-action", onClick: () => {
          setPartId("");
          setRevision(state.revision);
        }, children: "核对最新候选后继续" })
      ] }),
      saving.error && /* @__PURE__ */ jsx("p", { role: "alert", className: "ppe-error", children: saving.error })
    ] }),
    /* @__PURE__ */ jsxs("footer", { className: "ppe-footer", children: [
      /* @__PURE__ */ jsx("button", { type: "button", className: "btn subtle", disabled: saving.busy, onClick: onClose, children: "保留待核" }),
      /* @__PURE__ */ jsx("button", { type: "submit", disabled: !options.some((part) => part.id === partId) || !source.trim() || saving.busy || revision !== state.revision, className: "btn primary", children: saving.busy ? "正在保存…" : "确认归属" })
    ] })
  ] }) });
}
function shortModel(model) {
  return model.name.replace(/^H3C\s+UniServer\s+/i, "").replace(/^UniServer\s+/i, "");
}
function number(value) {
  return value === null ? "未知" : String(value);
}
function ResultTable({ rows, catalog, modelId, queried, open }) {
  const models = new Map(catalog.models.map((m) => [m.id, m]));
  return /* @__PURE__ */ jsxs("table", { className: "result-table", "aria-label": "备件查询结果", children: [
    /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
      /* @__PURE__ */ jsx("th", { children: "备件 / PN" }),
      /* @__PURE__ */ jsx("th", { children: "部件 / 规格" }),
      /* @__PURE__ */ jsx("th", { className: "num", children: "好件" }),
      /* @__PURE__ */ jsx("th", { className: "num", children: "坏件" }),
      /* @__PURE__ */ jsx("th", { children: modelId ? "安装位置" : "匹配机型" }),
      /* @__PURE__ */ jsx("th", { "aria-label": "查看档案" })
    ] }) }),
    /* @__PURE__ */ jsx("tbody", { children: rows.map(({ part, members, reasons }) => {
      const modelNames = members.map((m) => models.get(m.modelId)).filter((m) => Boolean(m)).map(shortModel);
      return /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsxs("td", { className: "identity-cell", children: [
          /* @__PURE__ */ jsxs("button", { className: "part-link", onClick: () => open(part), children: [
            /* @__PURE__ */ jsx("strong", { children: part.name }),
            /* @__PURE__ */ jsx("code", { children: part.pn })
          ] }),
          queried && reasons.length > 0 && /* @__PURE__ */ jsxs("div", { className: "reason", children: [
            "命中 ",
            reasons.join(" · ")
          ] })
        ] }),
        /* @__PURE__ */ jsxs("td", { className: "spec-cell", children: [
          /* @__PURE__ */ jsx("span", { className: "type-label", children: part.category }),
          part.specs.length > 0 && /* @__PURE__ */ jsx("span", { className: "spec-line", children: part.specs.join(" · ") })
        ] }),
        /* @__PURE__ */ jsxs("td", { className: "num", children: [
          /* @__PURE__ */ jsx("span", { className: "mobile-label", children: "好件 " }),
          /* @__PURE__ */ jsx("span", { className: part.good ? "qty good" : "qty", children: number(part.good) })
        ] }),
        /* @__PURE__ */ jsxs("td", { className: "num", children: [
          /* @__PURE__ */ jsx("span", { className: "mobile-label", children: "坏件 " }),
          /* @__PURE__ */ jsx("span", { className: part.bad ? "qty bad" : "qty", children: number(part.bad) })
        ] }),
        /* @__PURE__ */ jsxs("td", { className: "scope-cell", children: [
          /* @__PURE__ */ jsx("span", { className: "mobile-label", children: modelId ? "位置 " : "机型 " }),
          modelId ? members[0]?.position || "待补位置" : modelNames.join("、")
        ] }),
        /* @__PURE__ */ jsx("td", { className: "open-cell", children: /* @__PURE__ */ jsx("button", { className: "icon-button", "aria-label": "查看 " + part.pn + " 详情", onClick: () => open(part), children: /* @__PURE__ */ jsx(RightOutlined, { "aria-hidden": "true" }) }) })
      ] }, part.id);
    }) })
  ] });
}
function EmptyResults({ title, children }) {
  return /* @__PURE__ */ jsxs("div", { className: "empty-results", children: [
    /* @__PURE__ */ jsx(InboxOutlined, { "aria-hidden": "true" }),
    /* @__PURE__ */ jsx("strong", { children: title }),
    children
  ] });
}
function PendingList({ rows, catalog, onReview }) {
  return /* @__PURE__ */ jsx("div", { className: "pending-list", children: rows.map(
    (row) => /* @__PURE__ */ jsxs("div", { className: "pending-item", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("code", { children: row.rawPn }),
        /* @__PURE__ */ jsxs("div", { className: "list-secondary", children: [
          catalog.models.find((m) => m.id === row.modelId)?.name,
          " · ",
          row.position || "位置待补"
        ] }),
        row.source && /* @__PURE__ */ jsxs("div", { className: "list-secondary", children: [
          "来源 ",
          row.source
        ] })
      ] }),
      /* @__PURE__ */ jsx("span", { className: "pending-status", children: row.candidateIds.length ? row.candidateIds.length + " 个匹配档案" : "未匹配到档案" }),
      onReview && /* @__PURE__ */ jsx("button", { className: "btn", onClick: () => onReview(row), children: "核对归属" })
    ] }, row.id)
  ) });
}
function PartDetail({ part, catalog, result, onClose, onModel, commit, requireMembershipVersion, onMessage }) {
  const [removing, setRemoving] = useState(null);
  const saving = useSubmission();
  const members = catalog.members.filter((m) => m.partId === part.id);
  return /* @__PURE__ */ jsx(Dialog, { title: "备件档案", onClose: () => {
    if (!saving.busy) onClose();
  }, wide: true, children: /* @__PURE__ */ jsxs("div", { className: "detail-body", children: [
    /* @__PURE__ */ jsxs("div", { className: "detail-heading", children: [
      /* @__PURE__ */ jsx("span", { className: "type-label", children: part.category }),
      /* @__PURE__ */ jsx("h3", { children: part.name }),
      /* @__PURE__ */ jsx("code", { children: part.pn })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "detail-stock", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("span", { children: "好件在手" }),
        /* @__PURE__ */ jsx("strong", { children: number(part.good) })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("span", { children: "坏件在手" }),
        /* @__PURE__ */ jsx("strong", { children: number(part.bad) })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("span", { children: "已确认机型" }),
        /* @__PURE__ */ jsx("strong", { children: members.length })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("dl", { className: "detail-specs", children: [
      /* @__PURE__ */ jsx("dt", { children: "规格" }),
      /* @__PURE__ */ jsx("dd", { children: part.specs.join(" · ") || "待补充" }),
      /* @__PURE__ */ jsx("dt", { children: "档案别名" }),
      /* @__PURE__ */ jsx("dd", { children: part.aliases.join("、") || "暂无" }),
      Boolean(result?.reasons.length) && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("dt", { children: "查询命中" }),
        /* @__PURE__ */ jsx("dd", { children: result?.reasons.join(" · ") })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("h4", { className: "detail-section", children: [
      /* @__PURE__ */ jsx(ApartmentOutlined, { "aria-hidden": "true" }),
      " 所属机型"
    ] }),
    members.map((member) => {
      const model = catalog.models.find((m) => m.id === member.modelId);
      if (!model) return null;
      const missingVersion = requireMembershipVersion && !validMembershipVersion(member.membershipVersion);
      const changed = removing !== null && (removing.revision !== catalog.revision || removing.membershipVersion !== member.membershipVersion);
      return /* @__PURE__ */ jsxs("section", { className: "relation-card", children: [
        /* @__PURE__ */ jsxs("div", { className: "relation-head", children: [
          /* @__PURE__ */ jsxs("button", { className: "text-button", onClick: () => onModel(model.id), children: [
            model.name,
            " ",
            /* @__PURE__ */ jsx(RightOutlined, { "aria-hidden": "true" })
          ] }),
          commit && /* @__PURE__ */ jsx("button", { className: "bare small", disabled: saving.busy || missingVersion, onClick: () => {
            setRemoving({ model: model.id, revision: catalog.revision, membershipVersion: member.membershipVersion });
            saving.setError("");
          }, children: "移出此机型" })
        ] }),
        commit && missingVersion && /* @__PURE__ */ jsx("p", { className: "list-secondary", children: "缺少归属版本，请刷新清单后再移出。" }),
        /* @__PURE__ */ jsxs("dl", { className: "relation-fields", children: [
          /* @__PURE__ */ jsx("dt", { children: "部位" }),
          /* @__PURE__ */ jsx("dd", { children: member.position || "待补充" }),
          /* @__PURE__ */ jsx("dt", { children: "适用配置" }),
          /* @__PURE__ */ jsx("dd", { children: member.condition || "待补充" }),
          Boolean(member.rawPns?.length) && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx("dt", { children: "录入原号" }),
            /* @__PURE__ */ jsx("dd", { children: member.rawPns?.join("、") })
          ] }),
          /* @__PURE__ */ jsx("dt", { children: "归属依据" }),
          /* @__PURE__ */ jsx("dd", { children: member.source || "待补充来源" })
        ] }),
        commit && removing?.model === model.id && /* @__PURE__ */ jsxs("div", { className: "remove-check", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            "确认移出 ",
            shortModel(model),
            "？"
          ] }),
          /* @__PURE__ */ jsx("button", { className: "btn", disabled: saving.busy, onClick: () => setRemoving(null), children: "取消" }),
          /* @__PURE__ */ jsx("button", { className: "btn danger", disabled: saving.busy || missingVersion || changed, onClick: () => {
            void saving.submit(() => commit({ action: "remove", modelId: model.id, partId: part.id, expectedMembershipVersion: removing.membershipVersion }, removing.revision), () => {
              onMessage("已从 " + shortModel(model) + " 移出 " + part.pn);
              setRemoving(null);
            });
          }, children: saving.busy ? "正在保存…" : "确认移出" }),
          changed && /* @__PURE__ */ jsx("span", { children: "归属已更新，请重新选择要移出的归属。" })
        ] })
      ] }, model.id);
    }),
    members.length === 0 && /* @__PURE__ */ jsx("p", { className: "list-secondary", children: "此 PN 目前没有已确认的机型归属。" }),
    saving.error && /* @__PURE__ */ jsx("p", { role: "alert", className: "error-text", children: saving.error })
  ] }) });
}
const stockLabels = {
  all: "全部库存",
  good: "有好件",
  bad: "有坏件",
  zero: "零库存",
  unknown: "库存未知"
};
function initialView(catalog, defaultModel = "") {
  const url = new URLSearchParams(window.location.hash.slice(1));
  const target = url.get("model") ?? defaultModel;
  const stock = url.get("stock") ?? "all";
  return {
    modelId: catalog.models.some((model) => model.id === target) ? target : "",
    q: url.get("q") ?? "",
    pendingQ: url.get("pendingQ") ?? "",
    category: url.get("category") ?? "",
    stock: Object.prototype.hasOwnProperty.call(stockLabels, stock) ? stock : "all",
    tab: url.get("view") === "pending" ? "pending" : "members"
  };
}
function Directory({ models, members, selected, select }) {
  const counts = /* @__PURE__ */ new Map();
  for (const m of members) counts.set(m.modelId, (counts.get(m.modelId) ?? 0) + 1);
  return /* @__PURE__ */ jsxs("aside", { className: "directory", "aria-label": "机型目录", children: [
    /* @__PURE__ */ jsxs("div", { className: "directory-title", children: [
      /* @__PURE__ */ jsx("strong", { children: "机型目录" }),
      /* @__PURE__ */ jsxs("span", { children: [
        models.length,
        " 款"
      ] })
    ] }),
    /* @__PURE__ */ jsxs("button", { className: "directory-all" + (selected === "" ? " selected" : ""), "aria-current": selected === "" ? "true" : void 0, onClick: () => select(""), children: [
      /* @__PURE__ */ jsx(AppstoreOutlined, { "aria-hidden": "true" }),
      " ",
      /* @__PURE__ */ jsx("span", { children: "全部机型" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "model-list", children: models.map((m) => /* @__PURE__ */ jsxs(
      "button",
      {
        className: "model-item" + (m.id === selected ? " selected" : ""),
        "aria-current": m.id === selected ? "true" : void 0,
        title: m.name,
        onClick: () => select(m.id),
        children: [
          /* @__PURE__ */ jsx(HddOutlined, { "aria-hidden": "true" }),
          /* @__PURE__ */ jsxs("span", { children: [
            /* @__PURE__ */ jsx("strong", { children: shortModel(m) }),
            /* @__PURE__ */ jsx("small", { children: m.brand })
          ] }),
          /* @__PURE__ */ jsx("b", { children: counts.get(m.id) ?? 0 })
        ]
      },
      m.id
    )) }),
    /* @__PURE__ */ jsxs("label", { className: "mobile-model", children: [
      "机型范围",
      /* @__PURE__ */ jsxs("select", { "aria-label": "机型范围", value: selected, onChange: (e) => select(e.target.value), children: [
        /* @__PURE__ */ jsx("option", { value: "", children: "全部机型" }),
        models.map((m) => /* @__PURE__ */ jsx("option", { value: m.id, children: m.name }, m.id))
      ] })
    ] })
  ] });
}
function SearchBox({ query, setQuery, placeholder, label }) {
  const [draft, setDraft] = useState(query);
  const composing = useRef(false);
  useEffect(() => {
    if (!composing.current) setDraft(query);
  }, [query]);
  return /* @__PURE__ */ jsxs("div", { className: "search-box", children: [
    /* @__PURE__ */ jsx(SearchOutlined, { "aria-hidden": "true" }),
    /* @__PURE__ */ jsx(
      "input",
      {
        type: "text",
        autoComplete: "off",
        spellCheck: false,
        "aria-label": label,
        placeholder,
        value: draft,
        maxLength: 250,
        onCompositionStart: () => {
          composing.current = true;
        },
        onCompositionEnd: (e) => {
          composing.current = false;
          setQuery(e.currentTarget.value);
        },
        onChange: (e) => {
          setDraft(e.target.value);
          if (!composing.current) setQuery(e.target.value);
        }
      }
    ),
    draft && /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "清空" + label, className: "clear-input", onClick: () => {
      setDraft("");
      setQuery("");
    }, children: /* @__PURE__ */ jsx(CloseOutlined, { "aria-hidden": "true" }) })
  ] });
}
function maintenanceLink(base, context) {
  if (!base) return void 0;
  try {
    const target = new URL(base, window.location.href);
    if (!["https:", "http:"].includes(target.protocol) || target.username || target.password) return void 0;
    target.search = "";
    target.hash = context.toString();
    return target.href;
  } catch {
    return void 0;
  }
}
function Workbench({ catalog, commit, canMaintain, requireMembershipVersion = false, findCandidates, maintenanceUrl, examples, header, noticeBar, toolbar }) {
  const [view, setView] = useState(() => initialView(catalog, examples?.defaultModel));
  const [page, setPage] = useState(0);
  const [overlay, setOverlay] = useState(null);
  const [target, setTarget] = useState("");
  const [notice, setNotice] = useState("");
  const selected = catalog.models.find((m) => m.id === view.modelId);
  const scope = selected?.id ?? "";
  const filters = { q: view.q, modelId: scope, stock: view.stock, category: view.category };
  const results = useMemo(() => searchCatalog(catalog, filters), [catalog, view.q, scope, view.stock, view.category]);
  const members = catalog.members.filter((m) => !scope || m.modelId === scope);
  const pnCount = new Set(members.map((m) => m.partId)).size;
  const categories = Array.from(new Set(catalog.parts.map((p) => p.category))).filter(Boolean).sort((a, b) => a.localeCompare(b, "zh-CN"));
  const pending = catalog.pending.filter((p) => !scope || p.modelId === scope);
  const pendingTerms = view.pendingQ.normalize("NFKC").toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
  const pendingResults = pending.filter((row) => {
    const model = catalog.models.find((m) => m.id === row.modelId);
    const fields = [row.rawPn, row.position, row.condition, row.source, model?.name, model?.brand, ...model?.aliases ?? []].join(" ").normalize("NFKC").toLocaleLowerCase();
    return pendingTerms.every((term) => fields.includes(term));
  });
  const visibleCount = view.tab === "members" ? results.length : pendingResults.length;
  const pageSize = 50;
  const pages = Math.max(1, Math.ceil(visibleCount / pageSize));
  const currentPage = Math.min(page, pages - 1);
  const offset = currentPage * pageSize;
  const detail = overlay?.kind === "detail" ? catalog.parts.find((p) => p.id === overlay.id) : void 0;
  const review = overlay?.kind === "review" ? catalog.pending.find((p) => p.id === overlay.id) : void 0;
  function update(params) {
    setPage(0);
    setView((old) => ({ ...old, ...params }));
  }
  function switchModel(id, clean = false) {
    update(clean ? { modelId: id, q: "", pendingQ: "", category: "", stock: "all", tab: "members" } : { modelId: id, pendingQ: "" });
    setOverlay(null);
  }
  function saved(message, modelId) {
    if (modelId) switchModel(modelId, true);
    else setOverlay(null);
    setNotice(message);
  }
  function add() {
    if (scope) setOverlay({ kind: "import", id: scope });
    else if (catalog.models.length) {
      setTarget(catalog.models[0].id);
      setOverlay({ kind: "pick" });
    } else setOverlay({ kind: "new" });
  }
  function resetQuery() {
    update({ q: "", category: "", stock: "all" });
  }
  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(""), 6500);
    return () => window.clearTimeout(timer);
  }, [notice]);
  const context = new URLSearchParams({ model: view.modelId || "all" });
  if (view.q) context.set("q", view.q);
  if (view.pendingQ) context.set("pendingQ", view.pendingQ);
  if (view.category) context.set("category", view.category);
  if (view.stock !== "all") context.set("stock", view.stock);
  if (view.tab !== "members") context.set("view", view.tab);
  const locationHash = "#" + context.toString();
  useEffect(() => {
    try {
      window.history.replaceState(window.history.state, "", locationHash);
    } catch {
    }
  }, [locationHash]);
  const maintenanceHref = !canMaintain && maintenanceLink(maintenanceUrl, context);
  const hasFilters = Boolean(view.q || view.category || view.stock !== "all");
  const editorProps = { state: catalog, onClose: () => setOverlay(null), commit, onSaved: saved, findCandidates, examples };
  return /* @__PURE__ */ jsxs("div", { className: "model-workbench", children: [
    header,
    /* @__PURE__ */ jsxs("main", { className: "workspace", children: [
      /* @__PURE__ */ jsxs("section", { className: "page-heading", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h1", { children: "机型备件池" }),
          /* @__PURE__ */ jsx("p", { children: "按整机整理备件，按 PN 反查适用机型。" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "pool-actions", children: [
          toolbar,
          canMaintain && /* @__PURE__ */ jsxs("button", { className: "btn new-model", onClick: () => setOverlay({ kind: "new" }), children: [
            /* @__PURE__ */ jsx(PlusOutlined, { "aria-hidden": "true" }),
            "新建机型"
          ] }),
          maintenanceHref && /* @__PURE__ */ jsx("a", { className: "btn", href: maintenanceHref, referrerPolicy: "no-referrer", children: "在 itsp 维护" })
        ] })
      ] }),
      noticeBar,
      /* @__PURE__ */ jsxs("div", { className: "workspace-grid", children: [
        /* @__PURE__ */ jsx(Directory, { models: catalog.models, members: catalog.members, selected: scope, select: switchModel }),
        /* @__PURE__ */ jsxs("section", { className: "catalog-panel", "aria-label": "机型备件工作区", children: [
          /* @__PURE__ */ jsxs("header", { className: "model-heading", children: [
            /* @__PURE__ */ jsx("span", { className: "model-symbol", "aria-hidden": "true", children: selected ? /* @__PURE__ */ jsx(HddOutlined, { "aria-hidden": "true" }) : /* @__PURE__ */ jsx(ApartmentOutlined, { "aria-hidden": "true" }) }),
            /* @__PURE__ */ jsxs("div", { className: "model-heading-text", children: [
              /* @__PURE__ */ jsx("h2", { children: selected?.name || "全部机型" }),
              /* @__PURE__ */ jsx("p", { children: selected ? [selected.brand, ...selected.aliases.slice(0, 3)].filter(Boolean).join(" · ") : "跨机型查询，按 PN 合并显示结果" })
            ] }),
            canMaintain && /* @__PURE__ */ jsxs("button", { className: "btn primary add-member", onClick: add, children: [
              /* @__PURE__ */ jsx(PlusOutlined, { "aria-hidden": "true" }),
              "添加备件"
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "view-tabs", "aria-label": "清单视图", children: [
            /* @__PURE__ */ jsxs("button", { "aria-pressed": view.tab === "members", onClick: () => update({ tab: "members" }), children: [
              /* @__PURE__ */ jsx(FolderOpenOutlined, { "aria-hidden": "true" }),
              "备件清单 ",
              /* @__PURE__ */ jsx("span", { children: pnCount })
            ] }),
            /* @__PURE__ */ jsxs("button", { "aria-pressed": view.tab === "pending", onClick: () => update({ tab: "pending" }), children: [
              /* @__PURE__ */ jsx(FileSearchOutlined, { "aria-hidden": "true" }),
              "待核对 ",
              /* @__PURE__ */ jsx("span", { children: pending.length })
            ] })
          ] }),
          view.tab === "members" ? /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsxs("section", { className: "query-tools", "aria-label": "融合查询", children: [
              /* @__PURE__ */ jsx(SearchBox, { query: view.q, setQuery: (q) => update({ q }), label: "融合查询", placeholder: "搜索机型、PN、部件、规格或来源" }),
              /* @__PURE__ */ jsxs("div", { className: "filter-row", children: [
                /* @__PURE__ */ jsxs("label", { children: [
                  "部件类别",
                  /* @__PURE__ */ jsxs("select", { value: view.category, onChange: (e) => update({ category: e.target.value }), children: [
                    /* @__PURE__ */ jsx("option", { value: "", children: "全部类别" }),
                    categories.map((c) => /* @__PURE__ */ jsx("option", { children: c }, c))
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("label", { children: [
                  "库存条件",
                  /* @__PURE__ */ jsx("select", { value: view.stock, onChange: (e) => update({ stock: e.target.value }), children: Object.entries(stockLabels).map(([id, label]) => /* @__PURE__ */ jsx("option", { value: id, children: label }, id)) })
                ] }),
                hasFilters && /* @__PURE__ */ jsx("button", { className: "bare small", onClick: resetQuery, children: "清除条件" }),
                examples && /* @__PURE__ */ jsxs("details", { className: "example-menu", children: [
                  /* @__PURE__ */ jsx("summary", { children: "查询示例" }),
                  /* @__PURE__ */ jsx("div", { children: examples.queries.map((example) => /* @__PURE__ */ jsxs("button", { onClick: (e) => {
                    update({ modelId: "", q: example.q, category: "", stock: example.stock });
                    e.currentTarget.closest("details")?.removeAttribute("open");
                  }, children: [
                    /* @__PURE__ */ jsx("strong", { children: example.title }),
                    /* @__PURE__ */ jsx("span", { children: example.caption })
                  ] }, example.title)) })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "results-meta", "aria-live": "polite", children: [
              /* @__PURE__ */ jsxs("span", { children: [
                /* @__PURE__ */ jsx("b", { children: results.length }),
                " 个备件 PN"
              ] }),
              /* @__PURE__ */ jsx("small", { children: hasFilters ? "符合当前查询条件" : "含零库存备件" })
            ] }),
            results.length ? /* @__PURE__ */ jsx(ResultTable, { rows: results.slice(offset, offset + pageSize), catalog, modelId: scope, queried: Boolean(view.q.trim()), open: (p) => setOverlay({ kind: "detail", id: p.id }) }) : /* @__PURE__ */ jsx(EmptyResults, { title: hasFilters ? "没有符合条件的备件" : scope ? "这个机型还没有已确认的备件" : "还没有已确认的机型备件", children: hasFilters ? /* @__PURE__ */ jsx("button", { className: "btn", onClick: resetQuery, children: "清除查询条件" }) : canMaintain && /* @__PURE__ */ jsx("button", { className: "btn", onClick: add, children: "添加第一条备件" }) })
          ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsxs("div", { className: "query-tools pending-tools", children: [
              /* @__PURE__ */ jsx(SearchBox, { query: view.pendingQ, setQuery: (pendingQ) => update({ pendingQ }), label: "搜索待核对原号", placeholder: "搜索待核原号、机型或来源" }),
              /* @__PURE__ */ jsx("p", { children: "保留原始编号，核对档案后再计入机型清单。" })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "results-meta", "aria-live": "polite", children: /* @__PURE__ */ jsxs("span", { children: [
              /* @__PURE__ */ jsx("b", { children: pendingResults.length }),
              " 条待核记录"
            ] }) }),
            pendingResults.length ? /* @__PURE__ */ jsx(PendingList, { rows: pendingResults.slice(offset, offset + pageSize), catalog, onReview: canMaintain ? (row) => setOverlay({ kind: "review", id: row.id }) : void 0 }) : /* @__PURE__ */ jsx(EmptyResults, { title: view.pendingQ ? "没有符合条件的待核记录" : "当前范围没有待核记录" })
          ] }),
          pages > 1 && /* @__PURE__ */ jsxs("nav", { "aria-label": "清单分页", className: "pool-pagination", children: [
            /* @__PURE__ */ jsxs("span", { children: [
              "第 ",
              offset + 1,
              "–",
              Math.min(offset + pageSize, visibleCount),
              " 条，共 ",
              visibleCount,
              " 条"
            ] }),
            /* @__PURE__ */ jsx("button", { className: "btn", disabled: currentPage === 0, onClick: () => setPage(currentPage - 1), children: "上一页" }),
            /* @__PURE__ */ jsx("button", { className: "btn", disabled: currentPage + 1 >= pages, onClick: () => setPage(currentPage + 1), children: "下一页" })
          ] })
        ] })
      ] })
    ] }),
    canMaintain && overlay?.kind === "new" && /* @__PURE__ */ jsx(ModelEditor, { ...editorProps }),
    canMaintain && overlay?.kind === "import" && /* @__PURE__ */ jsx(ImportEditor, { ...editorProps, modelId: overlay.id }),
    canMaintain && overlay?.kind === "review" && review && /* @__PURE__ */ jsx(PendingEditor, { ...editorProps, row: review }),
    overlay?.kind === "detail" && detail && /* @__PURE__ */ jsx(
      PartDetail,
      {
        part: detail,
        catalog,
        result: results.find((r) => r.part.id === detail.id),
        onClose: editorProps.onClose,
        onModel: (id) => switchModel(id, true),
        commit: canMaintain ? commit : void 0,
        requireMembershipVersion,
        onMessage: setNotice
      }
    ),
    canMaintain && overlay?.kind === "pick" && /* @__PURE__ */ jsx(Dialog, { title: "选择要添加备件的机型", onClose: editorProps.onClose, children: /* @__PURE__ */ jsxs("div", { className: "help-body", children: [
      /* @__PURE__ */ jsxs("label", { className: "pick-target", children: [
        "目标机型",
        /* @__PURE__ */ jsx("select", { value: target, onChange: (e) => setTarget(e.target.value), children: catalog.models.map((m) => /* @__PURE__ */ jsx("option", { value: m.id, children: m.name }, m.id)) })
      ] }),
      /* @__PURE__ */ jsx("button", { className: "btn primary", onClick: () => setOverlay({ kind: "import", id: target }), children: "继续添加" })
    ] }) }),
    notice && /* @__PURE__ */ jsxs("div", { className: "toast", role: "status", children: [
      /* @__PURE__ */ jsx(CheckCircleOutlined, { "aria-hidden": "true" }),
      notice,
      /* @__PURE__ */ jsx("button", { "aria-label": "关闭操作提示", className: "bare", onClick: () => setNotice(""), children: /* @__PURE__ */ jsx(CloseOutlined, { "aria-hidden": "true" }) })
    ] })
  ] });
}
function statusCode(error) {
  if (!error || typeof error !== "object") return void 0;
  const source = error;
  return source.status ?? source.response?.status;
}
function requestId() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = bytes[6] & 15 | 64;
  bytes[8] = bytes[8] & 63 | 128;
  const hex = Array.from(bytes, (n) => n.toString(16).padStart(2, "0")).join("");
  return [hex.slice(0, 8), hex.slice(8, 12), hex.slice(12, 16), hex.slice(16, 20), hex.slice(20)].join("-");
}
function stockSummary(view) {
  if (view.stockStatus === "unavailable") return "Shop 库存暂时不可用，当前数量显示为未知。";
  if (!view.stockAsOf) return "库存来源为 Shop。";
  const time = new Date(view.stockAsOf);
  if (!Number.isFinite(time.getTime())) return "库存来源为 Shop。";
  return "Shop 库存更新于 " + time.toLocaleString("zh-CN", { hour12: false });
}
function LivePage({ host }) {
  const [received, setReceived] = useState(null);
  const view = received?.host === host ? received.view : null;
  const catalog = useMemo(() => {
    if (!view || view.stockStatus === "live") return view?.catalog;
    return { ...view.catalog, parts: view.catalog.parts.map((part) => ({ ...part, good: null, bad: null })) };
  }, [view]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const readRequest = useRef(null);
  const afterWrite = useRef(void 0);
  const acknowledgedRevision = useRef(0);
  const active = useRef(null);
  const pending = useRef(null);
  const refresh = useCallback(async () => {
    readRequest.current?.abort();
    const request = new AbortController();
    readRequest.current = request;
    setLoading(true);
    try {
      const snapshot = await host.read(request.signal);
      if (request.signal.aborted) return;
      if (snapshot.catalog.revision < acknowledgedRevision.current) throw new Error("最新保存的版本尚未读回，请再刷新清单。");
      setReceived({ host, view: snapshot });
      setError("");
    } catch (cause) {
      if (request.signal.aborted) return;
      const status = statusCode(cause);
      if (status === 401 || status === 403) setReceived(null);
      setError(errorText(cause));
    } finally {
      if (!request.signal.aborted) setLoading(false);
    }
  }, [host]);
  useEffect(() => {
    active.current = host;
    acknowledgedRevision.current = 0;
    pending.current = null;
    setReceived(null);
    setError("");
    void refresh();
    function onFocus() {
      if (document.visibilityState !== "hidden") void refresh();
    }
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);
    return () => {
      active.current = null;
      readRequest.current?.abort();
      window.clearTimeout(afterWrite.current);
      document.removeEventListener("visibilitychange", onFocus);
      window.removeEventListener("focus", onFocus);
    };
  }, [host, refresh]);
  const commit = async (action, revision) => {
    if (!view?.canMaintain || error || active.current !== host) throw new Error("请刷新目录并核对当前账号的维护权限。");
    if (revision < acknowledgedRevision.current) throw new Error("上一项修改已保存，请等最新清单读回再继续。");
    if (action.action === "remove" && !validMembershipVersion(action.expectedMembershipVersion)) throw new Error("缺少归属版本，请刷新清单后再移出。");
    const body = commandBody(action);
    const fingerprint = JSON.stringify(body);
    const attempt = pending.current?.fingerprint === fingerprint ? pending.current : { fingerprint, id: requestId(), revision };
    pending.current = attempt;
    let receipt;
    try {
      receipt = await host.command({ ...body, requestId: attempt.id, expectedRevision: attempt.revision });
    } catch (cause) {
      if (active.current === host) {
        const status = statusCode(cause);
        if (status && status >= 400 && status < 500 && status !== 408 && status !== 429) pending.current = null;
        if (status === 409 || status === 401 || status === 403) await refresh();
      }
      throw cause;
    }
    if (active.current !== host) throw new Error("当前账号已切换，请重新打开目录。");
    pending.current = null;
    acknowledgedRevision.current = Math.max(acknowledgedRevision.current, receipt.revision);
    readRequest.current?.abort();
    setLoading(true);
    window.clearTimeout(afterWrite.current);
    afterWrite.current = window.setTimeout(() => {
      if (active.current === host) void refresh();
    }, 0);
    return receipt;
  };
  const retry = /* @__PURE__ */ jsx("button", { type: "button", className: "btn", disabled: loading, onClick: () => void refresh(), children: loading ? "正在刷新…" : "刷新清单" });
  if (!view || !catalog) return /* @__PURE__ */ jsx("div", { className: "model-workbench", children: /* @__PURE__ */ jsxs("section", { className: "workspace", children: [
    /* @__PURE__ */ jsxs("header", { className: "page-heading", children: [
      /* @__PURE__ */ jsx("h1", { children: "机型备件池" }),
      retry
    ] }),
    error ? /* @__PURE__ */ jsxs("p", { className: "store-warning", role: "alert", children: [
      "机型清单读取失败。",
      error
    ] }) : /* @__PURE__ */ jsx("p", { role: "status", children: "正在读取机型与备件清单…" })
  ] }) });
  return /* @__PURE__ */ jsx(
    Workbench,
    {
      catalog,
      canMaintain: view.canMaintain,
      requireMembershipVersion: true,
      commit,
      findCandidates: host.candidates,
      maintenanceUrl: view.maintenanceUrl,
      toolbar: retry,
      noticeBar: /* @__PURE__ */ jsxs(Fragment, { children: [
        error && /* @__PURE__ */ jsxs("p", { className: "store-warning", role: "alert", children: [
          "刷新失败，当前显示上次读取的清单。",
          error
        ] }),
        /* @__PURE__ */ jsx("p", { className: view.stockStatus === "unavailable" ? "store-warning" : "pool-stock-status", children: stockSummary(view) })
      ] })
    }
  );
}
const workbenchCss = ':root {\n  color-scheme: light;\n  --ink: var(--c-text, #18181b);\n  --muted: var(--c-text2, #52525b);\n  --soft: var(--c-text3, #68686d);\n  --line: var(--c-border-soft, #e4e4e7);\n  --font-mono: "SFMono-Regular", Menlo, Consolas, "Liberation Mono", monospace;\n  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif;\n  background: var(--c-page, #f6f6f6);\n  color: var(--ink);\n}\n*, *::before, *::after { box-sizing: border-box; }\nbody { margin: 0; font-size: 14px; line-height: 1.5; }\nbutton, select, input, textarea { font: inherit; color: inherit; }\nbutton, select { cursor: pointer; }\nbutton:disabled { cursor: not-allowed; opacity: .52; }\nbutton:focus-visible, select:focus-visible, input:focus-visible, textarea:focus-visible, a:focus-visible {\n  outline: 2px solid #246944; outline-offset: 3px;\n}\ncode, .qty { font-family: var(--font-mono); font-variant-numeric: tabular-nums; }\n.masthead { background: #fff; border-bottom: 1px solid var(--line); }\n.masthead-inner, .workspace { max-width: 1400px; margin: 0 auto; padding-inline: clamp(22px, 4vw, 62px); }\n.masthead-inner { height: 63px; display: flex; align-items: center; justify-content: space-between; }\n.brand, .top-actions { display: flex; align-items: center; gap: 12px; }\n.brand-logo { background: #303436; color: white; display: grid; place-items: center; height: 33px; width: 36px; font: 700 15px var(--font-mono); border-radius: 7px; }\n.brand strong { font-size: 16px; letter-spacing: .02em; }\n.brand-divider { height: 16px; width: 1px; background: var(--line); margin-inline: 5px; }\n.section-brand { font-size: 13px; color: var(--muted); }\n.demo-marker { display: inline-flex; align-items: center; gap: 8px; font-size: 12px; color: var(--muted); }\n.demo-marker i { width: 7px; height: 7px; background: #718778; border-radius: 50%; }\n.icon-button, .clear-input, .bare { background: transparent; border: 0; padding: 0; }\n.icon-button { width: 33px; height: 33px; display: inline-grid; place-items: center; border-radius: 5px; font-size: 15px; color: var(--soft); }\n.icon-button:hover, .clear-input:hover { background: var(--c-inset, #f4f4f5); color: var(--ink); }\n.workspace { padding-bottom: 50px; }\n.page-heading { display: flex; justify-content: space-between; gap: 24px; align-items: center; padding-block: 33px 24px; }\n.page-heading h1 { font-size: clamp(26px, 3.4vw, 36px); line-height: 1.25; font-weight: 720; margin: 0; letter-spacing: -.045em; }\n.page-heading p { margin: 8px 0 0; color: var(--muted); }\n.btn { display: inline-flex; align-items: center; justify-content: center; gap: 7px; padding: 8px 15px;\n  min-height: 37px; border: 1px solid var(--c-border, #d4d4d8); background: white; border-radius: 7px; font-size: 13px; font-weight: 600; line-height: 1.4; }\n.btn:hover:not(:disabled) { background: var(--c-inset, #f4f4f5); border-color: #929397; }\n.btn.primary { background: var(--c-accent-strong, #27272a); color: white; border-color: var(--c-accent-strong, #27272a); }\n.btn.primary:hover:not(:disabled) { background: #46484b; }\n.btn.subtle { background: transparent; }\n.btn.danger { border-color: #e5c9bf; color: var(--c-danger, #b42318); }\n.workspace-grid { display: grid; grid-template-columns: 228px minmax(0, 1fr); gap: 20px; align-items: start; }\n.directory, .catalog-panel { background: var(--c-surface, #fff); border: 1px solid var(--line); border-radius: 11px; min-width: 0; }\n.directory { padding: 16px 10px 12px; position: sticky; top: 12px; }\n.directory-title { display: flex; align-items: center; justify-content: space-between; padding: 0 9px 13px; }\n.directory-title strong { font-size: 14px; }\n.directory-title > span { font-size: 12px; color: var(--soft); }\n.directory-all, .model-item { display: flex; align-items: center; width: 100%; gap: 10px; border: 1px solid transparent;\n  border-radius: 6px; background: transparent; text-align: left; color: var(--muted); }\n.directory-all { padding: 10px; font-size: 13px; font-weight: 600; }\n.model-list { display: grid; gap: 4px; border-top: 1px solid var(--line); padding-top: 10px; margin-top: 8px; }\n.model-item { padding: 10px 9px; }\n.directory-all:hover, .model-item:hover { background: #f7f7f7; }\n.directory .selected { background: #edf1ee; border-color: #d9e2da; color: #234e35; }\n.model-item > span:not(.anticon) { display: grid; min-width: 0; }\n.model-item strong { font-size: 14px; color: var(--ink); font-weight: 650; overflow-wrap: anywhere; }\n.model-item small { font-size: 11px; color: var(--soft); }\n.model-item b { margin-left: auto; min-width: 25px; text-align: center; padding: 1px 5px; border-radius: 4px;\n  color: #565e56; background: #f2f3f2; font: 12px/1.7 var(--font-mono); }\n.model-item.selected b { background: #dce7de; color: #264d31; }\n.mobile-model { display: none; }\n.model-heading { display: flex; gap: 15px; align-items: center; padding: 23px 25px 20px; }\n.model-symbol { display: grid; place-items: center; width: 47px; height: 47px; flex: none; color: #e7ece7; background: #333c35;\n  border: 1px solid #29302b; border-radius: 9px; font-size: 24px; }\n.model-heading-text { min-width: 0; }\n.model-heading h2 { font-size: clamp(18px, 2.3vw, 25px); font-weight: 670; line-height: 1.2; letter-spacing: -.035em; margin: 0; overflow-wrap: anywhere; }\n.model-heading p { margin: 5px 0 0; font-size: 12px; color: var(--soft); overflow-wrap: anywhere; }\n.add-member { margin-left: auto; flex: none; }\n.view-tabs { border-bottom: 1px solid var(--line); display: flex; gap: 24px; padding: 0 25px; }\n.view-tabs button { border: 0; border-bottom: 2px solid transparent; background: transparent; color: var(--muted);\n  padding: 9px 0 10px; display: flex; align-items: center; gap: 7px; font-size: 13px; }\n.view-tabs button[aria-pressed=true] { color: var(--ink); font-weight: 700; border-color: #38483e; }\n.view-tabs button span:not(.anticon) { min-width: 21px; padding: 0 5px; border-radius: 4px; background: var(--c-inset, #f4f4f5); color: var(--muted); text-align: center; font: 11px/1.7 var(--font-mono); }\n.query-tools { padding: 19px 25px 15px; border-bottom: 1px solid var(--line); }\n.search-box { display: flex; align-items: center; gap: 11px; min-height: 43px; padding: 0 12px; background: white; border: 1px solid #bfc4c0; border-radius: 7px; }\n.search-box > .anticon { font-size: 17px; color: #546258; }\n.search-box:focus-within { outline: 2px solid #699475; outline-offset: 1px; }\n.search-box input { flex: 1; width: 0; min-width: 1px; align-self: stretch; border: 0; background: transparent; padding: 9px 0; outline: none; }\n.search-box input:focus-visible { outline: none; }\n.search-box input::placeholder { color: #696f6c; }\n.clear-input { height: 31px; width: 31px; border-radius: 4px; color: var(--soft); }\n.filter-row { display: flex; flex-wrap: wrap; align-items: center; gap: 9px 15px; margin-top: 12px; }\n.filter-row label { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; color: var(--muted); }\n.filter-row select, .mobile-model select, .pick-target select { padding: 5px 7px; border: 1px solid var(--line); border-radius: 5px; color: var(--ink); background: white; max-width: 100%; }\n.filter-row select { font-size: 12px; min-height: 31px; }\n.text-button, .example-menu summary { border: 0; background: none; padding: 0; color: #285b3d; font-size: 12px; font-weight: 600; }\n.text-button:hover, .example-menu summary:hover { color: #153d26; text-decoration: underline; }\n.example-menu { position: relative; margin-left: auto; }\n.example-menu summary { cursor: pointer; padding: 5px 4px; }\n.example-menu > div { position: absolute; right: 0; z-index: 2; top: calc(100% + 2px); min-width: 237px; padding: 4px;\n  border: 1px solid var(--line); border-radius: 7px; background: white; box-shadow: 0 5px 16px #17251a1c; }\n.example-menu button { display: grid; gap: 3px; width: 100%; padding: 9px; text-align: left; background: none; border: 0; border-radius: 5px; }\n.example-menu button:hover { background: var(--c-inset, #f4f4f5); }.example-menu strong { font-size: 12px; }.example-menu button span { font-size: 11px; color: var(--muted); }\n.bare { color: var(--muted); }\n.bare:hover { color: var(--ink); text-decoration: underline; }\n.small { font-size: 12px; }\n.results-meta { display: flex; align-items: center; gap: 10px; padding: 12px 25px; min-height: 42px; }\n.results-meta span { font-size: 13px; }\n.results-meta b { font-family: var(--font-mono); }\n.results-meta small, .list-secondary, .pending-tools p { font-size: 12px; color: var(--soft); }\n.result-table { border-collapse: collapse; width: 100%; table-layout: fixed; font-size: 13px; }\n.result-table th, .result-table td { text-align: left; padding: 11px 8px; vertical-align: middle; border-top: 1px solid var(--line); overflow-wrap: anywhere; }\n.result-table th { background: #f7f8f7; font-weight: 600; color: var(--muted); padding-block: 7px; font-size: 12px; }\n.result-table th:first-child, .result-table td:first-child { padding-left: 25px; }\n.result-table th:nth-child(1) { width: 31%; }.result-table th:nth-child(2) { width: 27%; }\n.result-table th:nth-child(3), .result-table th:nth-child(4) { width: 7.5%; }\n.result-table th:last-child { width: 35px; }\n.result-table td.num, .result-table th.num { text-align: center; }\n.result-table tr:hover td { background: #fafbf9; }\n.part-link { text-align: left; background: none; border: 0; padding: 0; display: inline-grid; gap: 2px; max-width: 100%; }\n.part-link strong { font-size: 14px; font-weight: 650; }\n.part-link:hover strong { text-decoration: underline; }\n.part-link code { font-size: 12px; color: var(--muted); }\n.reason { font-size: 11px; margin-top: 3px; color: #386346; }\n.type-label { display: inline-block; color: #465047; background: #f0f3ef; border-radius: 4px; padding: 1px 6px; font-size: 11px; }\n.spec-line { display: block; font-size: 12px; color: var(--muted); margin-top: 3px; }\n.qty { color: var(--soft); }.qty.good { color: #21683e; font-weight: 700; }.qty.bad { color: #86521b; font-weight: 700; }\n.scope-cell { color: var(--muted); font-size: 12px; }\n.result-table td.open-cell { padding: 0 4px 0 0; text-align: center; }.open-cell .icon-button { width: 25px; font-size: 10px; }\n.mobile-label { display: none; }\n.empty-results { padding: 40px 14px 46px; display: grid; justify-items: center; gap: 10px; color: var(--muted); text-align: center; }\n.empty-results > .anticon { color: #818e83; font-size: 25px; }\n.pending-tools p { margin: 8px 0 0; }\n.pending-item { display: grid; grid-template-columns: 1fr auto auto; align-items: center; gap: 15px; padding: 15px 25px; border-top: 1px solid var(--line); overflow-wrap: anywhere; }\n.pending-item code { font-size: 13px; font-weight: 600; }\n.pending-status { font-size: 12px; color: var(--c-warning, #a15c00); }\n.detail-body, .help-body { padding: 20px 24px 24px; overflow-y: auto; min-height: 0; overflow-wrap: anywhere; }\n.detail-heading h3 { font-size: 24px; line-height: 1.25; margin: 7px 0 4px; }\n.detail-heading code { color: var(--muted); }\n.detail-stock { margin: 18px 0; display: grid; grid-template-columns: repeat(3, 1fr); border-block: 1px solid var(--line); }\n.detail-stock > div { display: grid; padding: 12px 3px; }\n.detail-stock span, .detail-specs dt, .relation-fields dt { color: var(--soft); font-size: 12px; }\n.detail-stock strong { font-size: 20px; font-variant-numeric: tabular-nums; }\n.detail-specs, .relation-fields { display: grid; grid-template-columns: auto 1fr; gap: 5px 15px; align-items: baseline; }\n.detail-specs dd, .relation-fields dd { margin: 0; font-size: 13px; }\n.detail-section { margin: 19px 0 9px; font-size: 14px; }.detail-section .anticon { margin-right: 4px; }\n.relation-card { border: 1px solid var(--line); padding: 12px 14px; border-radius: 7px; margin-top: 8px; }\n.relation-head, .remove-check, .store-warning, .toast { display: flex; align-items: center; gap: 10px; }\n.relation-head { justify-content: space-between; }.relation-head .text-button { text-align: left; font-size: 14px; }\n.relation-fields { margin: 9px 0 0; }\n.remove-check { flex-wrap: wrap; margin-top: 9px; color: var(--c-danger, #b42318); font-size: 12px; }\n.error-text { color: var(--c-danger, #b42318); }\n.help-body h3 { font-size: 15px; margin: 13px 0 3px; }.help-body h3:first-child { margin-top: 0; }\n.help-body p { color: var(--muted); margin: 4px 0 16px; }.help-body p:last-child { margin-bottom: 0; }\n.pick-target { display: grid; gap: 7px; margin-bottom: 15px; }\n.store-warning { margin-bottom: 15px; padding: 10px 13px; background: #fff8eb; border: 1px solid #ead2a6; border-radius: 6px; color: #795017; }\n.toast { position: fixed; z-index: 5; bottom: 20px; left: 50%; transform: translateX(-50%); max-width: calc(100% - 25px);\n  padding: 10px 15px; border-radius: 8px; background: #25382b; color: white; box-shadow: 0 6px 18px #202d2526; overflow-wrap: anywhere; }\n.toast .bare { color: white; }\n@media (max-width: 980px) {\n  .workspace-grid { grid-template-columns: 176px minmax(0,1fr); gap: 12px; }\n  .masthead-inner, .workspace { padding-inline: 18px; }\n  .model-heading, .query-tools { padding-inline: 16px; }\n  .view-tabs, .results-meta { padding-inline: 16px; }\n  .result-table th:first-child, .result-table td:first-child { padding-left: 16px; }\n  .example-menu { margin-left: 0; }\n}\n@media (max-width: 700px) {\n  .masthead-inner { height: 52px; }.masthead-inner, .workspace { padding-inline: 13px; }\n  .brand, .top-actions { gap: 7px; }.brand-logo { width: 29px; height: 29px; font-size: 12px; }\n  .brand strong { font-size: 14px; }.section-brand, .brand-divider { display: none; }\n  .demo-marker { font-size: 11px; gap: 5px; }.top-actions .icon-button { width: 32px; height: 40px; }\n  .page-heading { gap: 8px; align-items: flex-start; padding-block: 20px 15px; }\n  .page-heading p { font-size: 12px; margin-top: 5px; }.page-heading h1 { font-size: 26px; }\n  .new-model { flex: none; }.btn { min-height: 40px; padding-inline: 10px; }\n  .workspace-grid { display: block; }\n  .directory { position: static; padding: 8px 12px; margin-bottom: 10px; border-radius: 8px; }\n  .directory-title, .directory-all, .model-list { display: none; }\n  .mobile-model { display: flex; align-items: center; gap: 12px; font-size: 12px; color: var(--muted); }\n  .mobile-model select { min-width: 0; flex: 1; min-height: 38px; font-size: 14px; color: var(--ink); }\n  .model-heading { gap: 8px; padding: 16px 12px 10px; flex-wrap: wrap; }\n  .model-symbol { width: 34px; height: 34px; font-size: 17px; border-radius: 6px; }\n  .model-heading-text { flex: 1; }.model-heading h2 { font-size: 18px; }.model-heading p { font-size: 11px; }\n  .add-member { font-size: 12px; gap: 3px; }\n  .view-tabs { padding: 0 12px; gap: 16px; }.view-tabs button { min-height: 44px; }\n  .query-tools { padding: 12px; }.search-box { gap: 7px; }.search-box input { font-size: 16px; }\n  .filter-row { gap: 6px 10px; margin-top: 7px; }.filter-row select { min-height: 38px; }\n  .example-menu summary, .filter-row .bare { min-height: 34px; }.example-menu > div { position: static; max-width: 100%; min-width: 0; }\n  .results-meta { padding: 8px 12px; min-height: 34px; }\n  .result-table, .result-table tbody { display: block; }\n  .result-table thead { position: absolute; width: 1px; height: 1px; padding: 0; overflow: hidden; clip-path: inset(50%); }\n  .result-table tr { position: relative; display: flex; flex-wrap: wrap; gap: 4px 12px; border-top: 1px solid var(--line); padding: 10px 12px; }\n  .result-table td, .result-table td:first-child { display: block; padding: 0; border: 0; }\n  .result-table .identity-cell { flex: 0 0 calc(100% - 25px); }.part-link { min-height: 42px; }\n  .result-table .spec-cell { flex: 0 0 100%; }.spec-line { display: inline; margin: 0 0 0 6px; }\n  .mobile-label { display: inline; color: var(--soft); font-size: 11px; }\n  .scope-cell { flex-basis: 100%; }.result-table .open-cell { position: absolute; top: 9px; right: 4px; }\n  .open-cell .icon-button { height: 40px; width: 30px; }.reason { margin-bottom: 3px; }\n  .pending-item { grid-template-columns: 1fr auto; gap: 5px 8px; padding: 12px; }\n  .pending-item > div { grid-column: 1 / -1; }\n  .detail-body, .help-body { padding: 14px 16px; }\n  .relation-head { align-items: flex-start; flex-wrap: wrap; }\n  .toast { font-size: 12px; width: max-content; bottom: max(12px, env(safe-area-inset-bottom)); }\n}\n.pool-actions { display: flex; align-items: center; justify-content: flex-end; flex-wrap: wrap; gap: 7px; }\n.pool-actions a { text-decoration: none; }\n.pool-stock-status { margin: -6px 0 14px; color: var(--muted); font-size: 12px; }\n@media (max-width: 440px) {\n  .page-heading:has(.pool-actions .btn + .btn) { flex-wrap: wrap; }\n  .pool-actions { justify-content: flex-start; }\n}\n.pool-pagination { display: flex; flex-wrap: wrap; align-items: center; justify-content: flex-end; gap: 8px; padding: 12px 16px; border-top: 1px solid var(--line); }\n.pool-pagination span { margin-right: auto; font-size: 12px; color: var(--muted); }\n';
const editorsCss = ".ppe-dialog {\n  width: min(100% - 40px, 510px);\n  max-width: 100%;\n  max-height: min(88vh, 810px);\n  max-height: min(88dvh, 810px);\n  margin: auto;\n  padding: 0;\n  color: #202724;\n  background: #fff;\n  border: 1px solid #d6dcd8;\n  border-radius: 14px;\n  box-shadow: 0 18px 64px #15251d30;\n  font: inherit;\n}\n.ppe-dialog[open] { display: flex; flex-direction: column; }\n.ppe-dialog.ppe-wide { width: min(100% - 40px, 700px); }\n.ppe-dialog::backdrop { background: rgb(26 35 30 / 35%); }\n.ppe-dialog *, .ppe-dialog *::before, .ppe-dialog *::after { box-sizing: border-box; }\n.ppe-dialog .ppe-dialog-head {\n  display: flex; justify-content: space-between; align-items: flex-start; gap: 15px;\n  flex: none; padding: 21px 24px 17px; border-bottom: 1px solid #e1e5e2;\n}\n.ppe-dialog-head > div { min-width: 0; }\n.ppe-dialog-head h2 { margin: 0; font-size: 21px; letter-spacing: -.025em; color: #202724; line-height: 1.4; overflow-wrap: anywhere; }\n.ppe-dialog-head p { margin: 5px 0 0; color: #5a655f; overflow-wrap: anywhere; font-size: 13px; }\n.ppe-dialog .ppe-x {\n  align-self: flex-start; flex: none; width: 32px; height: 32px; padding: 0;\n  border: 1px solid #dde2de; border-radius: 7px; color: #414b44; background: white;\n  line-height: 1; font-family: system-ui,sans-serif; font-weight: 400; font-size: 22px; cursor: pointer;\n}\n.ppe-dialog .ppe-x:hover { background: #f2f5f3; }\n.ppe-dialog .ppe-body { min-height: 0; overflow: auto; padding: 19px 24px; overscroll-behavior: contain; }\n.ppe-dialog .ppe-form { display: flex; flex-direction: column; min-height: 0; margin: 0; }\n.ppe-fields { display: grid; gap: 16px; }\n.ppe-fields > label, .ppe-resolve { display: block; font-weight: 600; font-size: 13px; color: #38423b; }\n.ppe-fields label small { margin-left: 3px; color: #69746c; font-size: 12px; font-weight: 400; }\n.ppe-fields :is(input:not([type=checkbox]), select, textarea), .ppe-resolve select {\n  display: block; margin-top: 6px; padding: 9px 11px; width: 100%; min-width: 0; max-width: 100%; min-height: 41px;\n  border: 1px solid #bdc6bf; border-radius: 6px; background-color: #fff; color: #27312a;\n  font: inherit; font-weight: 400; line-height: 1.5;\n}\n.ppe-fields textarea { resize: vertical; }\n.ppe-fields textarea[spellcheck=false], .ppe-pn {\n  font-family: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace); overflow-wrap: anywhere;\n}\n.ppe-dialog :is(button, input, textarea, select):focus-visible {\n  outline: 2px solid #286448; outline-offset: 2px;\n}\n.ppe-dialog .ppe-help, .ppe-dialog .ppe-evidence {\n  color: #59665d; font-size: 12px; font-weight: 400; line-height: 1.55; overflow-wrap: anywhere;\n}\n.ppe-fields > label .ppe-help { display: block; margin-top: 5px; }\n.ppe-evidence { display: block; }\n.ppe-input-tip { margin: -7px 0 0; color: #59665d; font-size: 12px; line-height: 1.55; }\n.ppe-input-examples { display: flex; align-items: center; flex-wrap: wrap; gap: 8px 16px; }\n.ppe-sheet-hint { margin: 0 0 12px; padding: 9px 12px; border-left: 3px solid #a5b4ab; background: #f3f6f3; color: #404e45; font-size: 13px; line-height: 1.55; }\n.ppe-source-decision { font-size: 12px; color: #445249; }\n.ppe-source-decision strong { margin-left: 3px; }\n.ppe-dialog .ppe-text-action {\n  border: 0; padding: 4px 0; justify-self: start; color: #176346; cursor: pointer; background: transparent;\n  font: inherit; font-size: 13px; font-weight: 600; text-decoration: underline; text-underline-offset: 3px;\n}\n.ppe-dialog .ppe-footer {\n  flex: none; display: flex; flex-wrap: wrap; justify-content: flex-end; align-items: center; gap: 9px;\n  padding: 13px 24px; background: #fafbf9; border-top: 1px solid #e1e5e2;\n}\n.ppe-dialog button:disabled { cursor: default; }\n.ppe-dialog .ppe-error {\n  display: block; margin: 9px 0 0; padding: 9px 12px; border-radius: 6px;\n  background: #fff4ec; color: #873f19; font-size: 13px;\n}\n.ppe-segment {\n  display: inline-flex; gap: 3px; padding: 3px; margin-bottom: 19px; max-width: 100%;\n  background: #f1f3f1; border: 1px solid #e0e5df; border-radius: 8px;\n}\n.ppe-dialog .ppe-segment button {\n  min-height: 31px; padding: 4px 12px; border: 1px solid transparent;\n  border-radius: 5px; background: transparent; color: #4a564d; font: inherit; font-size: 13px; cursor: pointer;\n}\n.ppe-dialog .ppe-segment button[aria-pressed=true] {\n  border-color: #dbe1db; color: #172a1e; background: white; font-weight: 600; box-shadow: 0 1px 2px #25352a0d;\n}\n.ppe-picker, .ppe-preview { padding: 0; margin: 0; list-style: none; }\n.ppe-picker { max-height: 255px; overflow-y: auto; border: 1px solid #e1e5e1; border-radius: 7px; }\n.ppe-picker li { display: flex; justify-content: space-between; align-items: center; gap: 12px; padding: 8px 11px; }\n.ppe-picker li + li, .ppe-preview li + li { border-top: 1px solid #e5e9e5; }\n.ppe-picker li > span { min-width: 0; }\n.ppe-picker .ppe-pick { flex: none; white-space: nowrap; min-height: 32px; padding: 4px 9px; font-size: 12px; }\n.ppe-picker .ppe-pn { font-size: 13px; }\n.ppe-option-name { display: block; margin-top: 3px; overflow-wrap: anywhere; color: #566159; font-size: 12px; }\n.ppe-picker .ppe-noresult { padding: 16px; color: #566159; font-size: 13px; }\n.ppe-section-title { margin: 0 0 9px; font-size: 16px; line-height: 1.5; }\n.ppe-section-title:focus:not(:focus-visible) { outline: 0; }\n.ppe-counts { display: flex; gap: 15px; margin-bottom: 13px; flex-wrap: wrap; font-size: 13px; color: #526058; }\n.ppe-counts b { color: #29342c; font-size: 15px; }\n.ppe-preview { border: 1px solid #dce2dc; border-radius: 8px; overflow: hidden; }\n.ppe-preview li { padding: 12px; }\n.ppe-preview-main { display: flex; justify-content: space-between; align-items: center; gap: 8px; }\n.ppe-row-check { min-width: 0; display: flex; align-items: center; flex-wrap: wrap; gap: 5px 9px; }\n.ppe-row-check input { width: 16px; height: 16px; margin: 0; accent-color: #236748; flex-shrink: 0; }\n.ppe-line-number { color: #5b685f; font-size: 11px; }\n.ppe-row-check .ppe-pn { color: #243027; font-size: 13px; }\n.ppe-status { flex: none; font-size: 12px; line-height: 1.55; font-weight: 600; color: #59665e; }\n.ppe-status.ppe-match { color: #176441; }\n.ppe-status:is(.ppe-unknown,.ppe-ambiguous,.ppe-invalid) { color: #895617; }\n.ppe-row-detail { display: grid; margin: 4px 0 0 25px; gap: 2px; }\n.ppe-row-detail:empty { display: none; }\n.ppe-matched { color: #3e4b42; font-size: 13px; }\n.ppe-resolve { margin-top: 6px; max-width: 100%; color: #455148; font-size: 12px; }\n.ppe-resolve select { margin-top: 3px; min-height: 36px; }\n.ppe-pending-meta { display: grid; gap: 5px; margin: 0; padding: 12px 14px; background: #f5f7f4; border-radius: 7px; font-size: 13px; }\n.ppe-pending-meta div { display: flex; gap: 12px; align-items: baseline; }\n.ppe-pending-meta dt { flex: 0 0 60px; color: #57645b; }\n.ppe-pending-meta dd { margin: 0; overflow-wrap: anywhere; }\n@media (max-width: 700px) {\n  .ppe-dialog, .ppe-dialog.ppe-wide { width: calc(100% - 20px); max-height: 92vh; max-height: 92dvh; border-radius: 10px; }\n  .ppe-dialog .ppe-dialog-head { padding: 15px 16px; }\n  .ppe-dialog .ppe-body { padding: 14px 16px; }\n  .ppe-dialog .ppe-footer { padding: 11px 16px max(11px, env(safe-area-inset-bottom)); }\n  .ppe-dialog .ppe-footer .btn, .ppe-dialog .ppe-x, .ppe-picker .ppe-pick, .ppe-dialog .ppe-segment button { min-height: 42px; }\n  .ppe-dialog .ppe-x { min-width: 42px; }\n  .ppe-dialog .ppe-fields input, .ppe-dialog .ppe-fields textarea, .ppe-dialog .ppe-fields select, .ppe-dialog .ppe-resolve select { font-size: 16px; }\n  .ppe-dialog .ppe-text-action { min-height: 42px; }\n  .ppe-picker { max-height: 32dvh; }\n  .ppe-preview li { padding: 10px; }\n  .ppe-row-detail { margin-left: 0; }\n}\n";
const styles = workbenchCss.replace(":root", ":host") + editorsCss + `
  :host { display: block; min-width: 0; }
  .pool-content { min-width: 0; font-size: 14px; line-height: 1.5; }
  .pool-content .workspace { max-width: none; padding-inline: 0; }
  .pool-content .page-heading { padding-top: 8px; }
`;
function EmbeddedPage({ host }) {
  const [root, setRoot] = useState(null);
  const attach = useCallback((node) => {
    if (node) setRoot(node.shadowRoot ?? node.attachShadow({ mode: "open" }));
  }, []);
  return /* @__PURE__ */ jsx("div", { ref: attach, children: root && createPortal(/* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("style", { children: styles }),
    /* @__PURE__ */ jsx("div", { className: "pool-content", children: /* @__PURE__ */ jsx(LivePage, { host }) })
  ] }), root) });
}
export {
  EmbeddedPage as default
};
